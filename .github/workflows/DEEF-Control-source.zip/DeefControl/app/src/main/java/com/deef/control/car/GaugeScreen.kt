package com.deef.control.car

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.GridItem
import androidx.car.app.model.GridTemplate
import androidx.car.app.model.ItemList
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.deef.control.Settings
import com.deef.control.obd.ObdRepository
import com.deef.control.ui.GaugeRenderer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Schermata Android Auto: una pagina con i suoi quadranti (modello a griglia di Google).
 * Il pulsante in alto passa alla pagina successiva: con la rotella dell'MMI si porta il fuoco
 * sul pulsante e si preme. Non è possibile intercettare la sola rotazione della rotella.
 */
class GaugeScreen(ctx: CarContext) : Screen(ctx) {
    private var page = 0
    private val bmpSize = 320 // dimensione immagine: da regolare dopo i test sul display reale

    init {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    delay(1000) // Google limita la frequenza di aggiornamento dei modelli
                    invalidate()
                }
            }
        }
    }

    override fun onGetTemplate(): Template {
        val gauges = Settings.pageGauges(page)
        val values = ObdRepository.values.value
        val stats = ObdRepository.minMax.value
        val style = Settings.renderStyle()

        val list = ItemList.Builder()
        gauges.forEach { g ->
            val v = values[g.pidId]?.let { g.convert(it) }
            val st = stats[g.pidId]
            val bmp = Bitmap.createBitmap(bmpSize, bmpSize, Bitmap.Config.ARGB_8888)
            GaugeRenderer.draw(
                Canvas(bmp), bmpSize.toFloat(), bmpSize.toFloat(), g, v,
                st?.let { g.convert(it.first) }, st?.let { g.convert(it.second) }, style,
            )
            list.addItem(
                GridItem.Builder()
                    .setTitle(g.label)
                    .setText(GaugeRenderer.format(v, g) + " " + g.unit)
                    .setImage(CarIcon.Builder(IconCompat.createWithBitmap(bmp)).build(), GridItem.IMAGE_TYPE_LARGE)
                    .build()
            )
        }
        if (gauges.isEmpty()) {
            list.setNoItemsMessage("Pagina vuota: configurala nelle Impostazioni sul telefono")
        }

        val next = Action.Builder()
            .setTitle(Settings.titles[page] + " >")
            .setOnClickListener { page = (page + 1) % Settings.PAGES; invalidate() }
            .build()

        return GridTemplate.Builder()
            .setTitle("DEEF Control")
            .setHeaderAction(Action.APP_ICON)
            .setSingleList(list.build())
            .setActionStrip(ActionStrip.Builder().addAction(next).build())
            .build()
    }
}
