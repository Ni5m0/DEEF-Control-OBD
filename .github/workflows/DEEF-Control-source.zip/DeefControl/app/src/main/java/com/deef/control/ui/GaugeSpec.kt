package com.deef.control.ui

import android.graphics.Typeface
import com.deef.control.obd.Formula
import com.deef.control.obd.Pid

enum class GaugeFont(val label: String) {
    SISTEMA("Sistema"), CONDENSATO("Condensato"), MONO("Mono"), SOTTILE("Sottile"), SETTE_SEG("7 segmenti");

    fun typeface(): Typeface = when (this) {
        SISTEMA, SETTE_SEG -> Typeface.DEFAULT_BOLD
        CONDENSATO -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
        MONO -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        SOTTILE -> Typeface.create("sans-serif-light", Typeface.NORMAL)
    }
}

enum class BgStyle(val label: String) { NERO("Nero"), CARBONIO("Carbonio"), SFUMATO("Sfumato") }

/** Opzioni grafiche globali. */
class RenderStyle(val theme: GaugeTheme, val font: GaugeFont, val opacity: Float, val minMaxBelow: Boolean)

/** Conversioni di unità: la formula usa A come valore di partenza. */
enum class Conv(val label: String, val formula: String?, val unit: String?) {
    NONE("Nessuna", null, null),
    C_F("°C→°F", "A*1.8+32", "°F"),
    BAR_PSI("bar→psi", "A*14.5038", "psi"),
    KMH_MPH("km/h→mph", "A*0.621371", "mph"),
    KPA_PSI("kPa→psi", "A*0.145038", "psi"),
    CUSTOM("Formula", null, null),
}

/** Impostazioni di un singolo quadro (una delle 12 posizioni). Soglie e limiti sono nelle unità mostrate. */
data class SlotConfig(
    val enabled: Boolean = true,
    val pidId: String = "-",
    val showLabel: Boolean = true,
    val label: String = "",          // vuoto = nome corto del PID
    val unit: String = "",           // vuoto = unità automatica
    val yellow: Double? = null,      // soglia gialla
    val red: Double? = null,         // soglia rossa (null = soglia del PID)
    val intNumbers: Boolean = false,
    val conv: String = "NONE",
    val convFormula: String = "A",
    val color: Long = 0,             // 0 = colore del tema
    val hiVis: Boolean = false,      // lancetta ad alta visibilità
    val min: Double? = null,
    val max: Double? = null,
    val showScale: Boolean = true,   // numeri sulla scala
    val showMinMax: Boolean = false,
    val showPeak: Boolean = false,
)

/** Quadro già risolto: PID + impostazioni, pronto per essere disegnato. */
class GaugeSpec(
    val pidId: String,
    val label: String,
    val showLabel: Boolean,
    val unit: String,
    val min: Double,
    val max: Double,
    val yellow: Double?,
    val red: Double?,
    val intNumbers: Boolean,
    val color: Long,
    val hiVis: Boolean,
    val showScale: Boolean,
    val showMinMax: Boolean,
    val showPeak: Boolean,
    private val formula: String?,
) {
    /** Applica la conversione di unità al valore grezzo letto dall'auto. */
    fun convert(v: Double): Double =
        if (formula == null) v else (Formula.eval(formula, mapOf('A' to v)) ?: v)
}

object GaugeResolver {
    fun resolve(cfg: SlotConfig, pid: Pid): GaugeSpec {
        val conv = runCatching { Conv.valueOf(cfg.conv) }.getOrDefault(Conv.NONE)
        val formula: String? = if (conv == Conv.CUSTOM) cfg.convFormula else conv.formula
        fun cv(v: Double): Double = if (formula == null) v else (Formula.eval(formula, mapOf('A' to v)) ?: v)
        val mn = cfg.min ?: cv(pid.min)
        var mx = cfg.max ?: cv(pid.max)
        if (mx <= mn) mx = mn + 1.0
        return GaugeSpec(
            pidId = pid.id,
            label = cfg.label.ifBlank { pid.shortName },
            showLabel = cfg.showLabel,
            unit = cfg.unit.ifBlank { conv.unit ?: pid.unit },
            min = mn,
            max = mx,
            yellow = cfg.yellow,
            red = cfg.red ?: cv(pid.warn),
            intNumbers = cfg.intNumbers,
            color = cfg.color,
            hiVis = cfg.hiVis,
            showScale = cfg.showScale,
            showMinMax = cfg.showMinMax,
            showPeak = cfg.showPeak,
            formula = formula,
        )
    }
}
