package com.deef.control.obd

/** Piccolo calcolatore per formule come "(A*256+B)/4-40". Variabili: A-H (byte della risposta). */
object Formula {
    fun eval(expr: String, vars: Map<Char, Double>): Double? = try {
        val r = P(expr.replace(" ", ""), vars).parse()
        if (r.isNaN() || r.isInfinite()) null else r
    } catch (e: Exception) {
        null
    }

    private class P(val s: String, val v: Map<Char, Double>) {
        var i = 0

        fun parse(): Double {
            val r = expr()
            if (i != s.length) error("residuo")
            return r
        }

        fun expr(): Double {
            var r = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val t = term()
                r = if (op == '+') r + t else r - t
            }
            return r
        }

        fun term(): Double {
            var r = factor()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]
                val f = factor()
                r = if (op == '*') r * f else r / f
            }
            return r
        }

        fun factor(): Double {
            if (i >= s.length) error("fine")
            val c = s[i]
            return when {
                c == '-' -> { i++; -factor() }
                c == '+' -> { i++; factor() }
                c == '(' -> {
                    i++
                    val r = expr()
                    if (i >= s.length || s[i] != ')') error(")")
                    i++
                    r
                }
                c.isDigit() || c == '.' -> {
                    val st = i
                    while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                    s.substring(st, i).toDouble()
                }
                c.uppercaseChar() in 'A'..'H' -> { i++; v[c.uppercaseChar()] ?: 0.0 }
                else -> error("simbolo")
            }
        }
    }
}
