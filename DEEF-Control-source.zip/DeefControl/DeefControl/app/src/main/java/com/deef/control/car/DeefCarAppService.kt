package com.deef.control.car

import androidx.car.app.CarAppService
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator
import android.content.Intent
import com.deef.control.Settings
import com.deef.control.obd.ObdRepository

class DeefCarAppService : CarAppService() {
    // ATTENZIONE: ALLOW_ALL va bene solo per test. Per il Play Store serve la lista
    // dei host consentiti (vedi documentazione Car App Library).
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = object : Session() {
        override fun onCreateScreen(intent: Intent): Screen {
            Settings.init(carContext)
            ObdRepository.ensureStarted(carContext)
            val root = GaugeScreen(carContext)
            if (Settings.aaLayout == "SURFACE") {
                // schermo intero sopra l'elenco; "Elenco" o Indietro tornano al pannello
                carContext.getCarService(androidx.car.app.ScreenManager::class.java).push(SurfaceGaugeScreen(carContext))
            }
            return root
        }
    }
}
