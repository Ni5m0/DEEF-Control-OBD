package com.deef.control.car

import android.graphics.Canvas
import android.graphics.Rect
import com.deef.control.DragTimer
import com.deef.control.Settings
import com.deef.control.obd.ObdRepository
import com.deef.control.ui.Backgrounds
import com.deef.control.ui.GaugeRenderer

/** Disegno dello schermo intero, condiviso tra Android Auto e l'anteprima nell'app. */
object SurfaceRender {
    fun draw(canvas: Canvas, w: Int, h: Int, area: Rect, page: Int) {
        Backgrounds.draw(canvas, w.toFloat(), h.toFloat(), Settings.background, Settings.darken / 100f)
        val gauges = Settings.pageGauges(page)
        val style = Settings.renderStyle(compact = false)
        val values = ObdRepository.values.value
        val stats = ObdRepository.minMax.value
        val hists = ObdRepository.history.value
        val dragOn = Settings.dragEnabled
        val cells = cells(gauges.size, area, dragOn)
        cells.forEach { c ->
            val g = gauges[c[0].toInt()]
            val side = c[3]
            canvas.save()
            canvas.translate(c[1], c[2])
            val raw = values[g.pidId]
            val st = stats[g.pidId]
            GaugeRenderer.draw(
                canvas, side, side, g,
                raw?.let { g.convert(it) },
                st?.let { g.convert(it.first) }, st?.let { g.convert(it.second) },
                hists[g.pidId]?.map { g.convert(it) },
                style,
            )
            canvas.restore()
        }
        if (dragOn) {
            val ds = DragTimer.state.value
            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.WHITE
                textAlign = android.graphics.Paint.Align.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                textSize = area.height() * 0.05f
            }
            canvas.drawText(
                "Drag ${Settings.dragFrom}-${Settings.dragTo} · " + (ds.speed?.let { "%.0f km/h".format(it) } ?: "-- km/h") +
                    " · " + DragTimer.phaseText(ds) + " · best " + DragTimer.fmt(ds.bestMs),
                area.centerX().toFloat(), area.bottom - area.height() * 0.03f, p,
            )
        }
    }

    /** Posizioni dei quadranti: (indice, sinistra, alto, lato). Usata anche per il tocco prolungato nell'anteprima. */
    fun cells(n0: Int, area: Rect, dragOn: Boolean): List<FloatArray> {
        val gaugesSize = n0
        val top = area.top + (area.height() * 0.04f)
        val bottomPad = if (dragOn) area.height() * 0.12f else 0f
        val availH = area.bottom - top - bottomPad
        val aw = area.width().toFloat()
        // (indice quadrante, sinistra, alto, lato)
        val cells = ArrayList<FloatArray>()
        if (gaugesSize == 3 && aw / availH >= 1.3f) {
            // uno grande a sinistra e due impilati a destra: sfrutta tutta l'altezza
            val big = if (Settings.bigCenter) 1 else 0
            val others = (0..2).filter { it != big }
            val sBig = minOf(availH, aw * 0.62f)
            val sSmall = minOf(availH / 2f, aw - sBig)
            val total = sBig + sSmall
            val x0 = area.left + (aw - total) / 2f
            cells.add(floatArrayOf(big.toFloat(), x0, top + (availH - sBig) / 2f, sBig))
            others.forEachIndexed { k, gi ->
                cells.add(floatArrayOf(gi.toFloat(), x0 + sBig, top + (availH - 2 * sSmall) / 2f + k * sSmall, sSmall))
            }
        } else {
            val n = gaugesSize.coerceAtLeast(1)
            val cellW = aw / n
            val side = minOf(cellW, availH)
            (0 until gaugesSize).forEach { i ->
                cells.add(floatArrayOf(i.toFloat(), area.left + i * cellW + (cellW - side) / 2f, top + (availH - side) / 2f, side))
            }
        }
        // cursore di ingrandimento: scala dimensioni e posizioni attorno al centro dell'area disponibile
        val k = Settings.surfaceScale / 100f
        if (k != 1f) {
            val cx = area.left + aw / 2f
            val cy = top + availH / 2f
            cells.forEach { c ->
                c[1] = cx + (c[1] - cx) * k
                c[2] = cy + (c[2] - cy) * k
                c[3] = c[3] * k
            }
        }
        return cells
    }
}
