package com.deef.control.car

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.GridItem
import androidx.car.app.model.GridTemplate
import androidx.car.app.model.ItemList
import androidx.car.app.model.Pane
import androidx.car.app.model.PaneTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.deef.control.DragTimer
import com.deef.control.Settings
import com.deef.control.obd.ObdRepository
import com.deef.control.ui.GaugeRenderer
import com.deef.control.ui.GaugeSpec
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Schermata Android Auto. Due layout (Impostazioni → Android Auto):
 *  - PANE: un pannello con un'immagine grande che contiene i quadranti affiancati (più leggibile);
 *  - GRID: la griglia di Google, con quadranti piccoli.
 * Il pulsante in alto passa alla pagina successiva: con la rotella dell'MMI si porta il fuoco
 * sul pulsante e si preme. Non è possibile intercettare la sola rotazione della rotella.
 */
class GaugeScreen(ctx: CarContext) : Screen(ctx) {
    private var page = 0
    private val bmpSize = 360

    init {
        DragTimer.refresh(ctx)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    delay(1000) // Google limita la frequenza di aggiornamento dei modelli
                    invalidate()
                }
            }
        }
    }

    private fun draw(g: GaugeSpec, canvas: Canvas, w: Float, h: Float) {
        val raw = ObdRepository.values.value[g.pidId]
        val st = ObdRepository.minMax.value[g.pidId]
        val hist = ObdRepository.history.value[g.pidId]
        GaugeRenderer.draw(
            canvas, w, h, g,
            raw?.let { g.convert(it) },
            st?.let { g.convert(it.first) }, st?.let { g.convert(it.second) },
            hist?.map { g.convert(it) },
            Settings.renderStyle(compact = true),
        )
    }

    private fun valueText(g: GaugeSpec): String {
        val v = ObdRepository.values.value[g.pidId]?.let { g.convert(it) }
        return GaugeRenderer.format(v, g) + " " + g.unit
    }

    override fun onGetTemplate(): Template {
        Settings.visiblePage = page
        val gauges = Settings.pageGauges(page)
        val status = ObdRepository.status.value
        val title = "DEEF · " + status.take(34)

        val next = Action.Builder()
            .setTitle(Settings.titles[page] + " >")
            .setOnClickListener { page = (page + 1) % Settings.PAGES; invalidate() }
            .build()
        // Android Auto ammette un solo pulsante con testo: il secondo è solo con icona
        val full = Action.Builder()
            .setIcon(CarIcon.Builder(IconCompat.createWithResource(carContext, com.deef.control.R.drawable.ic_deef)).build())
            .setOnClickListener { screenManager.push(SurfaceGaugeScreen(carContext)) }.build()
        val strip = ActionStrip.Builder().addAction(next).addAction(full).build()

        if (Settings.aaLayout == "PANE") {
            val pane = Pane.Builder()
            if (gauges.isEmpty()) {
                pane.addRow(Row.Builder().setTitle("Pagina vuota").addText("Configurala nelle Impostazioni sul telefono").build())
            } else {
                val dragOn = Settings.dragEnabled
                gauges.take(if (dragOn) 3 else 4).forEach { g ->
                    pane.addRow(Row.Builder().setTitle(g.label + "   " + valueText(g)).build())
                }
                if (dragOn) {
                    val ds = DragTimer.state.value
                    pane.addRow(Row.Builder()
                        .setTitle("Drag " + Settings.dragFrom + "-" + Settings.dragTo + "  " + (ds.speed?.let { "%.0f km/h".format(it) } ?: "-- km/h"))
                        .addText(DragTimer.phaseText(ds) + " · best " + DragTimer.fmt(ds.bestMs))
                        .build())
                }
                // Il riquadro immagine di Android Auto è quasi quadrato: i quadranti vanno
                // disposti in una griglia 2x2 invece che in fila, così restano grandi.
                val side = 720
                val bmp = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                val cells = gauges.size + if (dragOn) 1 else 0
                val cw = side / 2f
                gauges.forEachIndexed { i, g ->
                    c.save()
                    when {
                        gauges.size == 1 && !dragOn -> { c.translate(0f, 0f); draw(g, c, side.toFloat(), side.toFloat()) }
                        cells <= 2 -> { c.translate(i * cw, side / 4f); draw(g, c, cw, cw) }
                        else -> { c.translate((i % 2) * cw, (i / 2) * cw); draw(g, c, cw, cw) }
                    }
                    c.restore()
                }
                if (dragOn) {
                    val ds = DragTimer.state.value
                    val idx = gauges.size
                    val (ox, oy, w) = if (cells <= 2) Triple(idx * cw, side / 4f, cw) else Triple((idx % 2) * cw, (idx / 2) * cw, cw)
                    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = android.graphics.Color.WHITE
                        textAlign = android.graphics.Paint.Align.CENTER
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                    }
                    c.save(); c.translate(ox, oy)
                    paint.textSize = w * 0.12f
                    c.drawText("DRAG " + Settings.dragFrom + "-" + Settings.dragTo, w / 2, w * 0.2f, paint)
                    paint.textSize = w * 0.26f
                    c.drawText(ds.speed?.let { "%.0f".format(it) } ?: "--", w / 2, w * 0.5f, paint)
                    paint.textSize = w * 0.09f
                    c.drawText("km/h GPS", w / 2, w * 0.6f, paint)
                    paint.textSize = w * 0.10f
                    c.drawText(when (ds.phase) {
                        com.deef.control.DragPhase.RUNNING -> DragTimer.fmt(ds.elapsedMs)
                        com.deef.control.DragPhase.DONE -> "FINE " + DragTimer.fmt(ds.lastMs)
                        com.deef.control.DragPhase.ARMED -> "PRONTO"
                        else -> "attesa"
                    }, w / 2, w * 0.76f, paint)
                    c.drawText("best " + DragTimer.fmt(ds.bestMs), w / 2, w * 0.9f, paint)
                    c.restore()
                }
                pane.setImage(CarIcon.Builder(IconCompat.createWithBitmap(bmp)).build())
            }
            return PaneTemplate.Builder(pane.build())
                .setTitle(title)
                .setHeaderAction(Action.APP_ICON)
                .setActionStrip(strip)
                .build()
        }

        val list = ItemList.Builder()
        gauges.forEach { g ->
            val bmp = Bitmap.createBitmap(bmpSize, bmpSize, Bitmap.Config.ARGB_8888)
            draw(g, Canvas(bmp), bmpSize.toFloat(), bmpSize.toFloat())
            list.addItem(
                GridItem.Builder()
                    .setTitle(g.label)
                    .setText(valueText(g))
                    .setImage(CarIcon.Builder(IconCompat.createWithBitmap(bmp)).build(), GridItem.IMAGE_TYPE_LARGE)
                    .build()
            )
        }
        if (gauges.isEmpty()) {
            list.setNoItemsMessage("Pagina vuota: configurala nelle Impostazioni sul telefono")
        }
        val gridTitle = if (Settings.dragEnabled) {
            val ds = DragTimer.state.value
            "Drag " + Settings.dragFrom + "-" + Settings.dragTo + ": " + DragTimer.phaseText(ds)
        } else title
        return GridTemplate.Builder()
            .setTitle(gridTitle)
            .setHeaderAction(Action.APP_ICON)
            .setSingleList(list.build())
            .setActionStrip(strip)
            .build()
    }
}
