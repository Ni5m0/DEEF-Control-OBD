package com.deef.control.car

import android.graphics.Rect
import android.view.Surface
import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.deef.control.DragTimer
import com.deef.control.Settings
import com.deef.control.obd.ObdRepository
import com.deef.control.ui.Backgrounds
import com.deef.control.ui.GaugeRenderer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Schermo intero Android Auto: disegna i quadranti direttamente su una Surface (come AA Torque),
 * quindi possono occupare tutto lo schermo. Usa il modello "navigazione" della Car App Library,
 * perciò va bene per uso personale/sideload ma NON per il Play Store (riservato alle app di navigazione).
 */
class SurfaceGaugeScreen(ctx: CarContext) : Screen(ctx) {
    private var page = 0
    private var surface: Surface? = null
    private var w = 0
    private var h = 0
    private var visible: Rect? = null
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    init {
        ctx.getCarService(AppManager::class.java).setSurfaceCallback(object : SurfaceCallback {
            override fun onSurfaceAvailable(c: SurfaceContainer) {
                surface = c.surface; w = c.width; h = c.height
                startLoop()
            }
            override fun onSurfaceDestroyed(c: SurfaceContainer) {
                job?.cancel(); surface = null
            }
            override fun onVisibleAreaChanged(r: Rect) { visible = r }
            override fun onStableAreaChanged(r: Rect) {}
        })
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) { job?.cancel(); scope.coroutineContext[Job]?.cancel() }
        })
    }

    private fun startLoop() {
        job?.cancel()
        job = scope.launch {
            while (isActive) {
                drawFrame()
                delay(150)
            }
        }
    }

    private fun drawFrame() {
        val s = surface ?: return
        if (!s.isValid) return
        val canvas = try { s.lockCanvas(null) } catch (e: Exception) { return } ?: return
        try {
            val area = visible?.takeIf { !it.isEmpty } ?: Rect(0, 0, w, h)
            Backgrounds.draw(canvas, w.toFloat(), h.toFloat(), Settings.background, Settings.darken / 100f)
            val gauges = Settings.pageGauges(page)
            val style = Settings.renderStyle(compact = false)
            val values = ObdRepository.values.value
            val stats = ObdRepository.minMax.value
            val hists = ObdRepository.history.value
            val dragOn = Settings.dragEnabled
            val top = area.top + (area.height() * 0.04f)
            val bottomPad = if (dragOn) area.height() * 0.12f else 0f
            val availH = area.bottom - top - bottomPad
            val n = gauges.size.coerceAtLeast(1)
            val cellW = area.width() / n.toFloat()
            val side = minOf(cellW, availH)
            gauges.forEachIndexed { i, g ->
                canvas.save()
                canvas.translate(area.left + i * cellW + (cellW - side) / 2f, top + (availH - side) / 2f)
                val raw = values[g.pidId]
                val st = stats[g.pidId]
                GaugeRenderer.draw(
                    canvas, side, side, g,
                    raw?.let { g.convert(it) },
                    st?.let { g.convert(it.first) }, st?.let { g.convert(it.second) },
                    hists[g.pidId]?.map { g.convert(it) },
                    style,
                )
                canvas.restore()
            }
            if (dragOn) {
                val ds = DragTimer.state.value
                val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.WHITE
                    textAlign = android.graphics.Paint.Align.CENTER
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    textSize = area.height() * 0.05f
                }
                canvas.drawText(
                    "Drag ${Settings.dragFrom}-${Settings.dragTo} · " + (ds.speed?.let { "%.0f km/h".format(it) } ?: "-- km/h") +
                        " · " + DragTimer.phaseText(ds) + " · best " + DragTimer.fmt(ds.bestMs),
                    area.centerX().toFloat(), area.bottom - area.height() * 0.03f, p,
                )
            }
        } finally {
            try { s.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
        }
    }

    override fun onGetTemplate(): Template {
        val strip = ActionStrip.Builder()
            .addAction(
                Action.Builder().setTitle(Settings.titles[page] + " >")
                    .setOnClickListener { page = (page + 1) % Settings.PAGES; invalidate() }.build()
            )
            .addAction(
                Action.Builder().setTitle("Elenco")
                    .setOnClickListener { screenManager.pop() }.build()
            )
            .build()
        return NavigationTemplate.Builder()
            .setActionStrip(strip)
            .setBackgroundColor(CarColor.createCustom(0xFF000000.toInt(), 0xFF000000.toInt()))
            .build()
    }
}
