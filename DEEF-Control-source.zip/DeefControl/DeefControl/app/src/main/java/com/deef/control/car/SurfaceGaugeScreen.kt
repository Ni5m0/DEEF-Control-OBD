package com.deef.control.car

import android.graphics.Rect
import android.view.Surface
import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.PlaceListMapTemplate
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.deef.control.DragTimer
import com.deef.control.Settings
import com.deef.control.obd.ObdRepository
import com.deef.control.ui.Backgrounds
import com.deef.control.ui.GaugeRenderer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Schermo intero Android Auto: disegna i quadranti direttamente su una Surface (come AA Torque),
 * quindi possono occupare tutto lo schermo. Usa il modello "navigazione" della Car App Library,
 * perciò va bene per uso personale/sideload ma NON per il Play Store (riservato alle app di navigazione).
 */
class SurfaceGaugeScreen(ctx: CarContext, private val mapMode: Boolean = false) : Screen(ctx) {
    private var page = 0
    private var surface: Surface? = null
    private var w = 0
    private var h = 0
    private var visible: Rect? = null
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    init {
        ctx.getCarService(AppManager::class.java).setSurfaceCallback(object : SurfaceCallback {
            override fun onSurfaceAvailable(c: SurfaceContainer) {
                surface = c.surface; w = c.width; h = c.height
                Settings.carW = w; Settings.carH = h
                ObdRepository.addLog("Schermo auto: " + w + "x" + h)
                startLoop()
            }
            override fun onSurfaceDestroyed(c: SurfaceContainer) {
                job?.cancel(); surface = null
            }
            override fun onVisibleAreaChanged(r: Rect) {
                visible = r
                Settings.carVisible = r.left.toString() + "," + r.top + "," + r.right + "," + r.bottom
                ObdRepository.addLog("Area visibile: " + Settings.carVisible)
            }
            override fun onStableAreaChanged(r: Rect) {}
        })
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) { job?.cancel(); scope.coroutineContext[Job]?.cancel() }
        })
    }

    private fun startLoop() {
        job?.cancel()
        job = scope.launch {
            var errors = 0
            while (isActive) {
                try {
                    drawFrame()
                    errors = 0
                } catch (e: Throwable) {
                    // un errore di disegno non deve mai chiudere l'app
                    if (errors++ == 0) ObdRepository.addLog("Schermo intero: " + e.javaClass.simpleName + " " + (e.message ?: ""))
                    if (errors > 20) { surface = null; return@launch }
                    delay(500)
                }
                delay(150)
            }
        }
    }

    private fun drawFrame() {
        val s = surface ?: return
        if (!s.isValid) return
        val canvas = try { s.lockCanvas(null) } catch (e: Exception) { return } ?: return
        try {
            val area = visible?.takeIf { !it.isEmpty } ?: Rect(0, 0, w, h)
            SurfaceRender.draw(canvas, w, h, area, page)
        } finally {
            try { s.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
        }
    }

    override fun onGetTemplate(): Template {
        Settings.visiblePage = page
        val strip = ActionStrip.Builder()
            .addAction(
                Action.Builder().setTitle(Settings.titles[page] + " >")
                    .setOnClickListener { page = (page + 1) % Settings.PAGES; invalidate() }.build()
            )
            .build()
        if (mapMode) {
            // SPERIMENTALE: modello mappa (categoria POI) invece del modello di navigazione
            return PlaceListMapTemplate.Builder()
                .setTitle("DEEF")
                .setLoading(true)
                .setActionStrip(strip)
                .build()
        }
        return NavigationTemplate.Builder()
            .setActionStrip(strip)
            .setBackgroundColor(CarColor.createCustom(0xFF000000.toInt(), 0xFF000000.toInt()))
            .build()
    }
}
