package com.deef.control.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/** Il Bluetooth è collegato ma l'auto non risponde (quadro spento, protocollo non trovato). */
class CarNotReady(msg: String) : IOException(msg)

/** Connessione Bluetooth classica (SPP) a un adattatore ELM327. */
class ElmConnection(private val adapter: BluetoothAdapter?, private val device: BluetoothDevice) {
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    /**
     * Apre il Bluetooth e inizializza l'ELM327. Prova tre modi di creare il socket (alcuni adattatori
     * economici ne accettano solo uno) e, se l'inizializzazione fallisce, passa al successivo.
     * Ritorna il numero del metodo riuscito, da riusare al tentativo seguente.
     */
    @SuppressLint("MissingPermission")
    fun open(startMethod: Int = 0, stage: (String) -> Unit = {}): Int {
        runCatching { adapter?.cancelDiscovery() } // può richiedere BLUETOOTH_SCAN: se manca, si prosegue
        val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        val makers = listOf<() -> BluetoothSocket>(
            { device.createRfcommSocketToServiceRecord(uuid) },
            { device.createInsecureRfcommSocketToServiceRecord(uuid) },
            {
                device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                    .invoke(device, 1) as BluetoothSocket
            },
        )
        var lastErr: Exception? = null
        for (k in makers.indices) {
            val idx = (startMethod + k) % makers.size
            var t: BluetoothSocket? = null
            try {
                stage("Bluetooth: collegamento (metodo ${idx + 1}/3)...")
                t = makers[idx]()
                t.connect()
                socket = t
                input = t.inputStream
                output = t.outputStream
                Thread.sleep(700) // alcuni adattatori hanno bisogno di una pausa dopo il collegamento
                initElm(stage)
                return idx
            } catch (e: CarNotReady) {
                throw e // il Bluetooth funziona: inutile provare altri metodi
            } catch (e: Exception) {
                lastErr = e
                runCatching { t?.close() }
                socket = null
                input = null
                output = null
                Thread.sleep(500)
            }
        }
        throw IOException(lastErr?.message ?: "connessione non riuscita")
    }

    private fun initElm(stage: (String) -> Unit) {
        stage("ELM327: reset...")
        var z = send("ATZ", 4000)
        if (z.isBlank()) z = send("ATZ", 4000)
        if (z.isBlank()) throw IOException("l'adattatore non risponde ai comandi (ATZ)")
        stage("ELM327: impostazioni...")
        for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATAT1", "ATST64")) send(c, 2000)
        send("ATSP0", 2000)
        // la prima richiesta avvia la ricerca del protocollo, che può durare diversi secondi
        stage("Auto: ricerca del protocollo (fino a 15 s)...")
        val r = send("0100", 15000).uppercase()
        if (r.contains("UNABLE") || r.contains("ERROR") || r.contains("BUS INIT")) {
            throw CarNotReady("l'auto non risponde (quadro acceso?): " + r.take(40))
        }
    }

    /** Invia un comando e legge fino al prompt '>'. */
    fun send(cmd: String, timeoutMs: Long = 3000): String {
        val o = output ?: throw IOException("non connesso")
        val i = input ?: throw IOException("non connesso")
        while (i.available() > 0) i.read() // scarta eventuali byte rimasti da risposte precedenti
        try {
            o.write((cmd + "\r").toByteArray())
            o.flush()
        } catch (e: IOException) {
            throw IOException("invio " + cmd + ": " + (e.message ?: "errore"))
        }
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (i.available() > 0) {
                val c = i.read()
                if (c < 0) throw IOException("connessione chiusa")
                val ch = c.toChar()
                if (ch == '>') break
                sb.append(ch)
            } else {
                Thread.sleep(5)
            }
        }
        return sb.toString().replace('\r', ' ').replace('\n', ' ').trim()
    }

    fun close() {
        runCatching { socket?.close() }
    }

    companion object {
        /** Estrae i byte A..H dalla risposta e applica la formula del PID. */
        fun decode(pid: Pid, resp: String): Double? {
            val cmd = pid.command.uppercase()
            if (cmd.length < 4) return null
            val mode = cmd.substring(0, 2).toIntOrNull(16) ?: return null
            val prefix = String.format("%02X", mode + 0x40) + cmd.substring(2)
            val clean = resp.replace(" ", "").uppercase()
            val idx = clean.indexOf(prefix)
            if (idx < 0) return null
            val data = clean.substring(idx + prefix.length)
            val bytes = data.chunked(2).take(8).mapNotNull { it.toIntOrNull(16) }
            if (bytes.isEmpty()) return null
            val vars = mutableMapOf<Char, Double>()
            for (c in 'A'..'H') vars[c] = 0.0
            bytes.forEachIndexed { n, b -> vars['A' + n] = b.toDouble() }
            return Formula.eval(pid.formula, vars)
        }
    }
}
