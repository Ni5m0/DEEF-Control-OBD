package com.deef.control

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

enum class DragPhase { OFF, NO_GPS, WAIT_START, ARMED, RUNNING, DONE }

data class DragState(
    val phase: DragPhase = DragPhase.OFF,
    val speed: Double? = null,      // km/h da GPS
    val elapsedMs: Long = 0,
    val lastMs: Long? = null,
    val bestMs: Long? = null,
)

/**
 * Cronometro "drag" basato sulla velocità GPS (da → a km/h, es. 0-100, 100-200, personalizzato).
 * Il GPS aggiorna ~1 volta al secondo: il tempo è interpolato linearmente tra due rilevazioni,
 * quindi è una stima (precisione tipica ±0,1–0,3 s). Da usare solo su strada chiusa/pista.
 */
object DragTimer {
    val state = MutableStateFlow(DragState())

    private var lm: LocationManager? = null
    private var listener: LocationListener? = null
    private var prevSpeed = -1.0
    private var prevT = 0L
    private var startT = 0L
    private var phase = DragPhase.OFF

    private fun key() = "${Settings.dragFrom}-${Settings.dragTo}"

    fun hasPermission(c: Context) =
        c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Avvia o ferma l'ascolto GPS in base all'interruttore nelle impostazioni. */
    @SuppressLint("MissingPermission")
    @Synchronized
    fun refresh(c: Context) {
        Settings.init(c.applicationContext)
        if (!Settings.dragEnabled) { stop(); return }
        if (!hasPermission(c)) { phase = DragPhase.NO_GPS; push(null); return }
        if (listener != null) return
        val m = c.applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val l = object : LocationListener {
            override fun onLocationChanged(loc: Location) = onFix(loc)
            override fun onProviderEnabled(p: String) {}
            override fun onProviderDisabled(p: String) {}
            @Deprecated("old API") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        }
        try {
            m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, 0f, l, Looper.getMainLooper())
        } catch (e: Exception) {
            phase = DragPhase.NO_GPS; push(null); return
        }
        lm = m; listener = l
        phase = DragPhase.WAIT_START
        prevSpeed = -1.0
        push(null)
    }

    @Synchronized
    fun stop() {
        listener?.let { runCatching { lm?.removeUpdates(it) } }
        listener = null; lm = null
        phase = DragPhase.OFF
        state.value = DragState()
    }

    /** Azzera la prova in corso e torna in attesa. */
    fun reset() {
        if (listener != null) phase = DragPhase.WAIT_START
        prevSpeed = -1.0
        push(state.value.speed)
    }

    fun clearBest() {
        Settings.setDragBest(key(), null)
        Settings.setDragLast(key(), null)
        push(state.value.speed)
    }

    private fun push(speed: Double?, elapsed: Long = 0) {
        val k = key()
        state.value = DragState(phase, speed, elapsed, Settings.dragLast(k), Settings.dragBest(k))
    }

    private fun onFix(loc: Location) {
        if (!loc.hasSpeed()) return
        val s = loc.speed * 3.6
        val t = loc.elapsedRealtimeNanos / 1_000_000
        val from = Settings.dragFrom.toDouble()
        val to = Settings.dragTo.toDouble()
        if (to <= from) { prevSpeed = s; prevT = t; push(s); return }

        when (phase) {
            DragPhase.WAIT_START, DragPhase.DONE -> {
                // pronto quando la velocità è sotto o uguale al valore di partenza
                if (s <= from + 1.0) phase = DragPhase.ARMED
            }
            else -> {}
        }
        if (phase == DragPhase.ARMED) {
            val moving = if (from <= 0.0) s >= 2.0 else s > from
            if (moving) {
                // interpolazione dell'istante in cui è stata superata la velocità di partenza
                startT = if (prevSpeed in 0.0..from && s > prevSpeed && t > prevT) {
                    (t - (t - prevT) * (s - from) / (s - prevSpeed)).toLong()
                } else t
                phase = DragPhase.RUNNING
            }
        }
        if (phase == DragPhase.RUNNING) {
            if (s >= to) {
                val endT = if (prevSpeed < to && s > prevSpeed) {
                    (prevT + (t - prevT) * (to - prevSpeed) / (s - prevSpeed)).toLong()
                } else t
                val dur = (endT - startT).coerceAtLeast(0)
                phase = DragPhase.DONE
                val k = key()
                Settings.setDragLast(k, dur)
                val b = Settings.dragBest(k)
                if (b == null || dur < b) Settings.setDragBest(k, dur)
                prevSpeed = s; prevT = t
                push(s, dur)
                return
            }
            if (s < from - 3.0 || t - startT > 90_000) {
                phase = DragPhase.WAIT_START // prova annullata
            } else {
                prevSpeed = s; prevT = t
                push(s, t - startT)
                return
            }
        }
        prevSpeed = s; prevT = t
        push(s, if (phase == DragPhase.DONE) (state.value.lastMs ?: 0) else 0)
    }

    fun fmt(ms: Long?): String = if (ms == null) "--.--" else String.format(java.util.Locale.US, "%.2f s", ms / 1000.0)

    fun phaseText(st: DragState): String = when (st.phase) {
        DragPhase.OFF -> "Drag spento"
        DragPhase.NO_GPS -> "GPS non disponibile (permesso?)"
        DragPhase.WAIT_START -> "Fermati: attendo ${Settings.dragFrom} km/h"
        DragPhase.ARMED -> "PRONTO · parti!"
        DragPhase.RUNNING -> "IN CORSO " + fmt(st.elapsedMs)
        DragPhase.DONE -> "FINITO " + fmt(st.lastMs)
    }
}

internal fun parseBests(s: String): JSONObject = runCatching { JSONObject(s) }.getOrDefault(JSONObject())
