package com.deef.control.obd

/** Un parametro da leggere: comando OBD + formula che usa i byte A..H della risposta. */
data class Pid(
    val id: String,
    val name: String,
    val shortName: String,
    val unit: String,
    val command: String,   // es. "010C" (modo 01) oppure "221234" (modo 22, personalizzato)
    val formula: String,   // es. "(A*256+B)/4"
    val min: Double,
    val max: Double,
    val warn: Double,      // oltre questo valore l'arco diventa rosso (sopra il massimo = nessuna zona)
    val custom: Boolean = false,
    val header: String = "", // intestazione ECU opzionale (es. 7E0), come nei PID di Torque
    val category: String = "", // gruppo nella libreria
)

/** Libreria interna di PID: si scelgono dall'editor del quadro, senza scriverli a mano. */
object BuiltInPids {
    private const val MOTORE = "Motore"
    private const val TEMP = "Temperature"
    private const val ARIA = "Aria e turbo"
    private const val CARB = "Carburante"
    private const val ELET = "Elettrico"
    private const val VAG = "Audi / VAG (Simos 18.1)"

    private fun p(
        id: String, name: String, short: String, unit: String, cmd: String, formula: String,
        mn: Double, mx: Double, warn: Double, cat: String, header: String = "",
    ) = Pid(id, name, short, unit, cmd, formula, mn, mx, warn, false, header, cat)

    val all: List<Pid> = listOf(
        // ---- Motore
        p("RPM", "Giri motore", "RPM", "rpm", "010C", "(A*256+B)/4", 0.0, 8000.0, 6500.0, MOTORE),
        p("SPEED", "Velocità", "KM/H", "km/h", "010D", "A", 0.0, 260.0, 250.0, MOTORE),
        p("LOAD", "Carico motore", "LOAD", "%", "0104", "A*100/255", 0.0, 100.0, 95.0, MOTORE),
        p("THROTTLE", "Farfalla", "THR", "%", "0111", "A*100/255", 0.0, 100.0, 101.0, MOTORE),
        p("PEDAL", "Posizione pedale acceleratore", "PEDALE", "%", "0149", "A*100/255", 0.0, 100.0, 101.0, MOTORE),
        p("TIMING", "Anticipo accensione", "ANT.", "°", "010E", "A/2-64", -20.0, 60.0, 999.0, MOTORE),
        p("TORQUE", "Coppia attuale", "COPPIA", "%", "0162", "A-125", -50.0, 125.0, 999.0, MOTORE),
        p("RUNTIME", "Tempo dall'avvio", "TEMPO", "s", "011F", "A*256+B", 0.0, 3600.0, 99999.0, MOTORE),

        // ---- Temperature
        p("COOLANT", "Temp. liquido", "H2O", "°C", "0105", "A-40", 40.0, 130.0, 110.0, TEMP),
        p("IAT", "Temp. aspirazione", "IAT", "°C", "010F", "A-40", -20.0, 80.0, 60.0, TEMP),
        p("OILTEMP", "Temp. olio (standard)", "OLIO", "°C", "015C", "A-40", 40.0, 150.0, 130.0, TEMP),
        p("AMBIENT", "Temp. esterna", "ESTERNA", "°C", "0146", "A-40", -20.0, 50.0, 999.0, TEMP),
        p("EGT1", "EGT banco 1 sensore 1", "EGT", "°C", "0178", "((B*256)+C)/10-40", 0.0, 1000.0, 850.0, TEMP),

        // ---- Aria e turbo
        p("BOOST", "Pressione turbo (calcolata da MAP)", "TURBO", "bar", "010B", "A/100-1.013", -1.0, 2.0, 1.8, ARIA),
        p("MAP", "Pressione collettore (MAP)", "MAP", "kPa", "010B", "A", 0.0, 255.0, 230.0, ARIA),
        p("BARO", "Pressione atmosferica", "BARO", "kPa", "0133", "A", 80.0, 110.0, 999.0, ARIA),
        p("MAF", "Flusso aria (MAF)", "MAF", "g/s", "0110", "(A*256+B)/100", 0.0, 300.0, 280.0, ARIA),
        p("LAMBDA", "Lambda comandato", "LAMBDA", "λ", "0144", "(A*256+B)*2/65536", 0.0, 2.0, 999.0, ARIA),

        // ---- Carburante
        p("STFT", "Correzione carburante breve (banco 1)", "STFT", "%", "0106", "(A-128)*100/128", -25.0, 25.0, 25.0, CARB),
        p("LTFT", "Correzione carburante lunga (banco 1)", "LTFT", "%", "0107", "(A-128)*100/128", -25.0, 25.0, 25.0, CARB),
        p("FUELLVL", "Livello carburante", "SERB.", "%", "012F", "A*100/255", 0.0, 100.0, 101.0, CARB),
        p("FUELPRESS", "Pressione carburante", "P.CARB", "kPa", "010A", "A*3", 0.0, 765.0, 999.0, CARB),
        p("RAIL", "Pressione rail", "RAIL", "kPa", "0123", "(A*256+B)*10", 0.0, 25000.0, 24000.0, CARB),
        p("FUELRATE", "Consumo istantaneo", "CONSUMO", "L/h", "015E", "(A*256+B)/20", 0.0, 50.0, 999.0, CARB),

        // ---- Elettrico
        p("VOLT", "Tensione centralina", "VOLT", "V", "0142", "(A*256+B)/1000", 8.0, 16.0, 15.5, ELET),

        // ---- Audi / VAG (servizio 22, ECU 7E0)
        p("OILP_S", "Oil Pressure Simos", "Oil Press", "bar", "22204C", "((A*256)+B)/100", 0.0, 10.0, 10.0, VAG, "7E0"),
        p("OILT_S", "Oil Temp Simos", "Oil Temp", "°C", "22202F", "(((A*256)+B)-2731.4)/10", -50.0, 150.0, 130.0, VAG, "7E0"),
    )
}
