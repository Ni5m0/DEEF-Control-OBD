package com.deef.control

import android.content.Context
import android.content.SharedPreferences
import com.deef.control.obd.BuiltInPids
import com.deef.control.obd.Pid
import com.deef.control.ui.BgStyle
import com.deef.control.ui.GaugeFont
import com.deef.control.ui.GaugeResolver
import com.deef.control.ui.GaugeSpec
import com.deef.control.ui.GaugeTheme
import com.deef.control.ui.RenderStyle
import com.deef.control.ui.SlotConfig
import org.json.JSONArray
import org.json.JSONObject

object Settings {
    /** Link per offrire un caffe (es. https://paypal.me/NOME/2EUR). Finche contiene TUONOME il pulsante resta nascosto. */
    const val COFFEE_URL = "https://py.pl/pYnF1YLNeYrUNJKLZ0Z5dQ"

    const val PAGES = 4
    const val SLOTS = 3
    private const val DEFAULT_SLOTS = "RPM,BOOST,COOLANT,SPEED,LOAD,THROTTLE,IAT,OILTEMP,-,-,-,-"

    private lateinit var p: SharedPreferences

    fun init(c: Context) {
        if (!::p.isInitialized) {
            p = c.applicationContext.getSharedPreferences("deef", Context.MODE_PRIVATE)
            // salva l'ultimo arresto improvviso, così si può leggere nelle Impostazioni
            val prev = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                runCatching {
                    val sw = java.io.StringWriter()
                    e.printStackTrace(java.io.PrintWriter(sw))
                    val txt = java.text.SimpleDateFormat("dd/MM HH:mm:ss", java.util.Locale.US).format(java.util.Date()) +
                        " [" + t.name + "]\n" + sw.toString().take(2500)
                    p.edit().putString("lastcrash", txt).commit()
                    val app = c.applicationContext
                    app.startActivity(
                        android.content.Intent(app, CrashActivity::class.java)
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK)
                            .putExtra("t", txt)
                    )
                    Thread.sleep(400)
                }
                prev?.uncaughtException(t, e)
            }
            // prima installazione (nessun layout salvato): parte già con il layout S1
            if (!p.contains("slotcfg") && !p.contains("slots")) applyS1Preset()
        }
    }

    // ---------- adattatore ----------
    var deviceAddress: String
        get() = p.getString("dev", "") ?: ""
        set(v) { p.edit().putString("dev", v).apply() }

    /** Dongle BLE ISO-TP (ESP32, come per Simos Tools) al posto dell'adattatore ELM327. */
    var bleMode: Boolean
        get() = p.getBoolean("ble_mode", false)
        set(v) { p.edit().putBoolean("ble_mode", v).apply() }
    var bleAddress: String
        get() = p.getString("ble_addr", "") ?: ""
        set(v) { p.edit().putString("ble_addr", v).apply() }
    /** Password del dongle BLE (esadecimale), la stessa che manda Simos App. */
    var blePassword: String
        get() = p.getString("ble_pw", "141E22244673") ?: "141E22244673"
        set(v) { p.edit().putString("ble_pw", v.replace(" ", "").uppercase()).apply() }
    var bleName: String
        get() = p.getString("ble_name", "") ?: ""
        set(v) { p.edit().putString("ble_name", v).apply() }

    /** Protocollo OBD: "6" = CAN 11 bit 500k (Audi/VAG), "0" = ricerca automatica, "7" = CAN 29 bit 500k, "8" = CAN 11 bit 250k. */
    var protocol: String
        get() = p.getString("proto", "6") ?: "6"
        set(v) { p.edit().putString("proto", v).apply() }

    /** Se falso, l'app non si connette da sola (l'utente ha premuto "Disconnetti"). */
    var autoConnect: Boolean
        get() = p.getBoolean("autoconnect", true)
        set(v) { p.edit().putBoolean("autoconnect", v).apply() }

    var lastCrash: String
        get() = p.getString("lastcrash", "") ?: ""
        set(v) { p.edit().putString("lastcrash", v).apply() }

    /** Modalità beta sperimentale dello schermo intero (servizio con categoria POI). */
    var betaFull: Boolean
        get() = p.getBoolean("beta_full", false)
        set(v) { p.edit().putBoolean("beta_full", v).apply() }

    /** Posizione e dimensione libere dei quadranti a schermo intero: slot -> (centro x, centro y, lato) come frazioni dell'area visibile. */
    private fun surfMap(): MutableMap<Int, FloatArray> {
        val m = HashMap<Int, FloatArray>()
        for (e in (p.getString("surf_layout", "") ?: "").split(";")) {
            val a = e.split(":")
            if (a.size != 2) continue
            val k = a[0].toIntOrNull() ?: continue
            val v = a[1].split(",").mapNotNull { it.toFloatOrNull() }
            if (v.size == 3) m[k] = floatArrayOf(v[0], v[1], v[2])
        }
        return m
    }
    /** Un solo layout per tutte le pagine: posizione e dimensione del 1°, 2° e 3° quadrante valgono su ogni pagina. */
    var sharedLayout: Boolean
        get() = p.getBoolean("shared_layout", true)
        set(v) { p.edit().putBoolean("shared_layout", v).apply() }
    private fun lk(slot: Int) = if (sharedLayout) slot % SLOTS else slot

    fun surfLayout(slot: Int): FloatArray? = surfMap()[lk(slot)]
    fun setSurfLayout(slot0: Int, v: FloatArray?) {
        val slot = lk(slot0)
        val m = surfMap()
        if (v == null) m.remove(slot) else m[slot] = v
        p.edit().putString("surf_layout", m.entries.joinToString(";") { it.key.toString() + ":" + it.value.joinToString(",") }).apply()
    }

    /** Schermo intero diviso: quadranti a sinistra, valori scritti a destra. */
    var splitText: Boolean
        get() = p.getBoolean("split_text", false)
        set(v) { p.edit().putBoolean("split_text", v).apply() }
    var splitPct: Int
        get() = p.getInt("split_pct", 65)
        set(v) { p.edit().putInt("split_pct", v.coerceIn(30, 90)).apply() }

    /** Layout libero del Dash sul telefono: stesso formato di surf_layout. */
    private fun phoneMap(): MutableMap<Int, FloatArray> {
        val m = HashMap<Int, FloatArray>()
        for (e in (p.getString("phone_layout", "") ?: "").split(";")) {
            val a = e.split(":")
            if (a.size != 2) continue
            val k = a[0].toIntOrNull() ?: continue
            val v = a[1].split(",").mapNotNull { it.toFloatOrNull() }
            if (v.size == 3) m[k] = floatArrayOf(v[0], v[1], v[2])
        }
        return m
    }
    fun phoneLayout(slot: Int): FloatArray? = phoneMap()[lk(slot)]
    fun setPhoneLayout(slot0: Int, v: FloatArray?) {
        val slot = lk(slot0)
        val m = phoneMap()
        if (v == null) m.remove(slot) else m[slot] = v
        p.edit().putString("phone_layout", m.entries.joinToString(";") { it.key.toString() + ":" + it.value.joinToString(",") }).apply()
    }

    /** Esporta posizioni e dimensioni dei quadranti (auto e telefono) come testo JSON. */
    fun exportLayout(): String = org.json.JSONObject().apply {
        put("version", 1)
        put("shared", sharedLayout)
        put("surf_layout", p.getString("surf_layout", "") ?: "")
        put("phone_layout", p.getString("phone_layout", "") ?: "")
        put("surface_scale", surfaceScale)
        put("split_text", splitText)
        put("split_pct", splitPct)
    }.toString(2)

    fun saveLayoutSnapshot() { p.edit().putString("layout_snapshot", exportLayout()).apply() }
    fun restoreLayoutSnapshot(): Boolean = p.getString("layout_snapshot", null)?.let { importLayout(it) } ?: false

    fun importLayout(text: String): Boolean = try {
        val o = org.json.JSONObject(text)
        val e = p.edit()
        e.putBoolean("shared_layout", o.optBoolean("shared", true))
        e.putString("surf_layout", o.optString("surf_layout", ""))
        e.putString("phone_layout", o.optString("phone_layout", ""))
        e.putInt("surface_scale", o.optInt("surface_scale", 100).coerceIn(40, 140))
        e.putBoolean("split_text", o.optBoolean("split_text", false))
        e.putInt("split_pct", o.optInt("split_pct", 65).coerceIn(30, 90))
        e.apply()
        true
    } catch (e: Exception) { false }

    /** Dimensione dei quadranti a schermo intero in Android Auto, in % (100 = automatico). */
    var surfaceScale: Int
        get() = p.getInt("surface_scale", 100)
        set(v) { p.edit().putInt("surface_scale", v.coerceIn(40, 140)).apply() }

    /** Dimensioni reali dello schermo dell'auto, rilevate quando si usa lo schermo intero (per l'anteprima). */
    var carW: Int
        get() = p.getInt("car_w", 0)
        set(v) { p.edit().putInt("car_w", v).apply() }
    var carH: Int
        get() = p.getInt("car_h", 0)
        set(v) { p.edit().putInt("car_h", v).apply() }
    var carVisible: String
        get() = p.getString("car_vis", "") ?: ""
        set(v) { p.edit().putString("car_vis", v).apply() }

    // ---------- drag GPS ----------
    var dragEnabled: Boolean
        get() = p.getBoolean("drag_on", false)
        set(v) { p.edit().putBoolean("drag_on", v).apply() }

    var dragFrom: Int
        get() = p.getInt("drag_from", 0)
        set(v) { p.edit().putInt("drag_from", v).apply() }

    var dragTo: Int
        get() = p.getInt("drag_to", 100)
        set(v) { p.edit().putInt("drag_to", v).apply() }

    private fun dragMap(name: String) = parseBests(p.getString(name, "{}") ?: "{}")
    fun dragBest(k: String): Long? = dragMap("drag_best").let { if (it.has(k)) it.getLong(k) else null }
    fun dragLast(k: String): Long? = dragMap("drag_last").let { if (it.has(k)) it.getLong(k) else null }
    fun setDragBest(k: String, v: Long?) = setDragMap("drag_best", k, v)
    fun setDragLast(k: String, v: Long?) = setDragMap("drag_last", k, v)
    private fun setDragMap(name: String, k: String, v: Long?) {
        val o = dragMap(name)
        if (v == null) o.remove(k) else o.put(k, v)
        p.edit().putString(name, o.toString()).apply()
    }

    // ---------- aspetto ----------
    var theme: GaugeTheme
        get() = runCatching { GaugeTheme.valueOf(p.getString("theme", "COCKPIT") ?: "COCKPIT") }
            .getOrDefault(GaugeTheme.COCKPIT)
        set(v) { p.edit().putString("theme", v.name).apply() }

    var font: GaugeFont
        get() = runCatching { GaugeFont.valueOf(p.getString("font", "SISTEMA") ?: "SISTEMA") }
            .getOrDefault(GaugeFont.SISTEMA)
        set(v) { p.edit().putString("font", v.name).apply() }

    var background: BgStyle
        get() = runCatching { BgStyle.valueOf(p.getString("bg", "CARBONIO") ?: "CARBONIO") }
            .getOrDefault(BgStyle.CARBONIO)
        set(v) { p.edit().putString("bg", v.name).apply() }

    /** Scurisci lo sfondo, 0-100. */
    var darken: Int
        get() = p.getInt("darken", 0).coerceIn(0, 100)
        set(v) { p.edit().putInt("darken", v).apply() }

    /** Sfocatura dello sfondo, 0-20 (solo Android 12 o successivo). */
    var blur: Int
        get() = p.getInt("blur", 0).coerceIn(0, 20)
        set(v) { p.edit().putInt("blur", v).apply() }

    /** Opacità degli indicatori, 0-100. */
    var opacity: Int
        get() = p.getInt("opacity", 100).coerceIn(0, 100)
        set(v) { p.edit().putInt("opacity", v).apply() }

    var bigCenter: Boolean
        get() = p.getBoolean("bigcenter", true)
        set(v) { p.edit().putBoolean("bigcenter", v).apply() }

    var minMaxBelow: Boolean
        get() = p.getBoolean("mmbelow", false)
        set(v) { p.edit().putBoolean("mmbelow", v).apply() }

    /** Numero di quadri mostrati per pagina (1-3). */
    var perPage: Int
        get() = p.getInt("perpage", 3).coerceIn(1, SLOTS)
        set(v) { p.edit().putInt("perpage", v).apply() }

    /** Grandezza dei quadranti sul telefono in verticale (0.5 - 1.0 della larghezza). */
    var scale: Float
        get() = p.getFloat("scale", 1f).coerceIn(0.5f, 1f)
        set(v) { p.edit().putFloat("scale", v).apply() }

    val titles: List<String>
        get() {
            val raw = (p.getString("titles", "") ?: "").split("|")
            return List(PAGES) { i -> raw.getOrNull(i)?.takeIf { it.isNotBlank() } ?: "Pagina ${i + 1}" }
        }

    fun setTitle(i: Int, t: String) {
        val l = (0 until PAGES).map { j -> if (j == i) t.replace('|', ' ') else titles[j] }
        p.edit().putString("titles", l.joinToString("|")).apply()
    }

    fun renderStyle(compact: Boolean = false): RenderStyle =
        RenderStyle(theme, font, opacity / 100f, minMaxBelow, compact)

    /** Layout della schermata Android Auto: "GRID" (griglia) oppure "PANE" (pannello con immagine grande). */
    var aaLayout: String
        get() = p.getString("aalayout", "SURFACE") ?: "SURFACE"
        set(v) { p.edit().putString("aalayout", v).apply() }

    // ---------- quadri (4 pagine x 3 posizioni) ----------
    var slotConfigs: List<SlotConfig>
        get() {
            val s = p.getString("slotcfg", null)
            if (s == null) {
                val ids = (p.getString("slots", DEFAULT_SLOTS) ?: DEFAULT_SLOTS).split(",")
                return List(PAGES * SLOTS) { SlotConfig(pidId = ids.getOrElse(it) { "-" }) }
            }
            val arr = JSONArray(s)
            return List(PAGES * SLOTS) { i ->
                if (i >= arr.length()) SlotConfig() else slotFromJson(arr.getJSONObject(i))
            }
        }
        set(v) {
            val arr = JSONArray()
            v.forEach { arr.put(slotToJson(it)) }
            p.edit().putString("slotcfg", arr.toString()).apply()
        }

    fun setSlot(i: Int, c: SlotConfig) {
        val l = slotConfigs.toMutableList()
        l[i] = c
        slotConfigs = l
    }

    private fun slotToJson(c: SlotConfig) = JSONObject().apply {
        put("enabled", c.enabled); put("pid", c.pidId); put("showLabel", c.showLabel)
        put("label", c.label); put("unit", c.unit)
        c.yellow?.let { put("yellow", it) }
        c.red?.let { put("red", it) }
        c.low?.let { put("low", it) }
        put("decimals", c.decimals); put("type", c.type); put("size", c.size.toDouble())
        put("int", c.intNumbers); put("conv", c.conv); put("convF", c.convFormula)
        put("color", c.color); put("hiVis", c.hiVis)
        c.min?.let { put("min", it) }
        c.max?.let { put("max", it) }
        put("showScale", c.showScale); put("showMinMax", c.showMinMax); put("showPeak", c.showPeak)
    }

    private fun slotFromJson(o: JSONObject) = SlotConfig(
        enabled = o.optBoolean("enabled", true),
        pidId = o.optString("pid", "-"),
        showLabel = o.optBoolean("showLabel", true),
        label = o.optString("label", ""),
        unit = o.optString("unit", ""),
        yellow = if (o.has("yellow")) o.getDouble("yellow") else null,
        red = if (o.has("red")) o.getDouble("red") else null,
        low = if (o.has("low")) o.getDouble("low") else null,
        decimals = o.optInt("decimals", -1),
        type = o.optString("type", "DIAL"),
        size = o.optDouble("size", 1.0).toFloat(),
        intNumbers = o.optBoolean("int", false),
        conv = o.optString("conv", "NONE"),
        convFormula = o.optString("convF", "A"),
        color = o.optLong("color", 0L),
        hiVis = o.optBoolean("hiVis", false),
        min = if (o.has("min")) o.getDouble("min") else null,
        max = if (o.has("max")) o.getDouble("max") else null,
        showScale = o.optBoolean("showScale", true),
        showMinMax = o.optBoolean("showMinMax", false),
        showPeak = o.optBoolean("showPeak", false),
    )

    // ---------- PID ----------
    var customPids: List<Pid>
        get() {
            val arr = JSONArray(p.getString("custom", "[]") ?: "[]")
            return (0 until arr.length()).map { n ->
                val o = arr.getJSONObject(n)
                Pid(
                    o.getString("id"), o.getString("name"), o.getString("short"), o.getString("unit"),
                    o.getString("cmd"), o.getString("formula"),
                    o.getDouble("min"), o.getDouble("max"), o.getDouble("warn"), true,
                    o.optString("header", ""),
                )
            }
        }
        set(v) {
            val arr = JSONArray()
            v.forEach {
                arr.put(JSONObject().apply {
                    put("id", it.id); put("name", it.name); put("short", it.shortName)
                    put("unit", it.unit); put("cmd", it.command); put("formula", it.formula)
                    put("min", it.min); put("max", it.max); put("warn", it.warn)
                    put("header", it.header)
                })
            }
            p.edit().putString("custom", arr.toString()).apply()
        }

    fun allPids(): List<Pid> = BuiltInPids.all + customPids

    /** Quadri visibili di una pagina (solo posizioni abilitate, entro il numero di quadri per pagina). */
    fun pageGauges(page: Int): List<GaugeSpec> {
        val all = allPids()
        val cfgs = slotConfigs
        return (0 until perPage).mapNotNull { s ->
            val c = cfgs[page * SLOTS + s]
            if (!c.enabled) null else all.find { it.id == c.pidId }?.let { GaugeResolver.resolve(c, it, page * SLOTS + s) }
        }
    }

    /** Pagina mostrata nell'auto (condivisa tra tutte le schermate dell'auto e il thread di disegno). */
    @Volatile var carPage: Int = 0

    /** Pagina attualmente mostrata (telefono o auto): i suoi PID vengono letti più spesso. */
    @Volatile var visiblePage: Int = 0

    /** Tutti i PID usati nelle pagine (quelli da leggere dall'adattatore). */
    fun activePids(pages: IntRange = 0 until PAGES): List<Pid> {
        val all = allPids()
        val byId = all.associateBy { it.id.uppercase() }
        val cfgs = slotConfigs
        val ids = LinkedHashSet<String>()
        for (pg in pages) for (s in 0 until perPage) {
            val c = cfgs[pg * SLOTS + s]
            if (c.enabled && c.pidId != "-") ids.add(c.pidId)
        }
        // i PID calcolati richiedono anche i PID da cui dipendono (es. MAF per la potenza)
        var changed = true
        while (changed) {
            changed = false
            for (id in ids.toList()) {
                val pid = byId[id.uppercase()] ?: continue
                if (!pid.isCalc) continue
                for (m in Regex("[A-Za-z_][A-Za-z0-9_]*").findAll(pid.formula)) {
                    if (m.value.length < 2) continue
                    val dep = byId[m.value.uppercase()] ?: continue
                    if (ids.add(dep.id)) changed = true
                }
            }
        }
        return ids.mapNotNull { byId[it.uppercase()] }
    }

    /** Impostazioni di fabbrica: schermo intero, 4 pagine pronte per l'Audi S1, drag 100-200. */
    fun applyS1Preset() {
        val l = slotConfigs.toMutableList()
        val ids = listOf(
            "EGT1", "OILP_S", "OILT_S",        // pagina 1: DEEF CONTROL
            "V_AFR", "BOOST", "COOLANT",       // pagina 2: motore
            "OILP_S", "OILT_S", "EGT1",        // pagina 3: olio / EGT
            "RPM", "HP_MAP", "TQ_MAP",         // pagina 4: potenza
        )
        ids.forEachIndexed { i, id -> l[i] = SlotConfig(pidId = id) }
        slotConfigs = l
        setTitle(0, "DEEF CONTROL")
        setTitle(1, "Motore")
        setTitle(2, "Olio / EGT")
        setTitle(3, "Potenza")
        p.edit()
            .putString("aalayout", "SURFACE")                 // schermo intero
            .putString("bg", "NERO").putInt("blur", 16).putInt("darken", 0).putInt("opacity", 100)
            .putBoolean("bigcenter", true)
            .putBoolean("shared_layout", true)
            // tre quadranti alla stessa distanza, dimensione 60%
            .putString("surf_layout", "0:0.1882,0.46,0.6;1:0.5001,0.46,0.6;2:0.8118,0.46,0.6")
            .putBoolean("drag_on", true).putInt("drag_from", 100).putInt("drag_to", 200)
            .apply()
    }
}
