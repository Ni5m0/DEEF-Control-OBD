package com.deef.control

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.deef.control.ui.BgStyle
import java.io.File

/** Sfondo con una foto scelta dall'utente: file originale (ridotto) e file ritagliato sul formato dello schermo. */
object PhotoBg {
    @Volatile var dir: File? = null
    private fun f(name: String) = File(dir ?: File("/nonexistent"), name)
    fun cropFile() = f("bg_photo.jpg")
    fun originalFile() = f("bg_original.jpg")
    fun hasOriginal() = originalFile().exists()

    /** Copia la foto scelta (ridotta a max ~2400 px e raddrizzata) come originale da ritagliare. */
    fun importFrom(ctx: Context, uri: Uri): Boolean {
        return try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false
            val rot = cr.openInputStream(uri)?.use { s ->
                when (android.media.ExifInterface(s).getAttributeInt(
                    android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)) {
                    android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } ?: 0
            if (rot != 0) {
                val m = Matrix().apply { postRotate(rot.toFloat()) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            originalFile().outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            true
        } catch (e: Exception) { false }
    }

    fun loadOriginal(): Bitmap? =
        if (originalFile().exists()) runCatching { BitmapFactory.decodeFile(originalFile().path) }.getOrNull() else null

    fun saveCrop(bmp: Bitmap) {
        cropFile().outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
    }
}

/** Pulsanti per scegliere e ritagliare la foto di sfondo. */
@Composable
fun PhotoBgControls(onPicked: () -> Unit) {
    val ctx = LocalContext.current
    var crop by remember { mutableStateOf<Bitmap?>(null) }
    var msg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (PhotoBg.importFrom(ctx, uri)) { crop = PhotoBg.loadOriginal(); msg = "" }
            else msg = "Non riesco a leggere questa foto"
        }
    }
    val cw = Settings.carW.takeIf { it > 0 } ?: 800
    val ch = Settings.carH.takeIf { it > 0 } ?: 480
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { picker.launch("image/*") }) { Text("Scegli una foto…") }
            if (PhotoBg.hasOriginal()) OutlinedButton(onClick = { crop = PhotoBg.loadOriginal() }) { Text("Ritaglia di nuovo") }
        }
        Text(
            "La foto viene ritagliata sul formato dello schermo dell'auto (${cw}x$ch). " +
                "Sul telefono in verticale si vede la parte centrale.",
            fontSize = 12.sp,
        )
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp)
    }
    crop?.let { b ->
        PhotoCropDialog(
            src = b, aspect = cw.toFloat() / ch,
            onCancel = { crop = null },
            onDone = { out ->
                PhotoBg.saveCrop(out)
                Settings.background = BgStyle.FOTO
                onPicked()
                crop = null
            },
        )
    }
}

@Composable
fun PhotoCropDialog(src: Bitmap, aspect: Float, onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            var fw by remember { mutableFloatStateOf(0f) }
            var fh by remember { mutableFloatStateOf(0f) }
            var z by remember { mutableFloatStateOf(1f) }
            var ox by remember { mutableFloatStateOf(0f) }
            var oy by remember { mutableFloatStateOf(0f) }
            var started by remember { mutableStateOf(false) }
            val bw = src.width.toFloat()
            val bh = src.height.toFloat()
            fun s0(): Float = if (fw <= 0f || fh <= 0f) 1f else maxOf(fw / bw, fh / bh)
            fun clampOffsets() {
                val iw = bw * s0() * z
                val ih = bh * s0() * z
                ox = ox.coerceIn(minOf(0f, fw - iw), 0f)
                oy = oy.coerceIn(minOf(0f, fh - ih), 0f)
            }
            fun zoomAround(nz: Float, cx: Float, cy: Float) {
                val k = nz / z
                ox = cx - (cx - ox) * k
                oy = cy - (cy - oy) * k
                z = nz
            }
            val paint = remember { Paint(Paint.FILTER_BITMAP_FLAG) }
            Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.Center) {
                Text("Ritaglia lo sfondo: trascina la foto e usa due dita (o il cursore) per ingrandire.", color = Color.White, fontSize = 13.sp)
                Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                    androidx.compose.foundation.layout.Box(
                        Modifier.fillMaxWidth().aspectRatio(aspect).clipToBounds().background(Color(0xFF111111))
                            .onSizeChanged {
                                fw = it.width.toFloat(); fh = it.height.toFloat()
                                if (!started && fw > 0f) {
                                    started = true
                                    ox = (fw - bw * s0()) / 2f
                                    oy = (fh - bh * s0()) / 2f
                                }
                            }
                            .pointerInput(Unit) {
                                detectTransformGestures { centroid, pan, zoom, _ ->
                                    zoomAround((z * zoom).coerceIn(1f, 6f), centroid.x, centroid.y)
                                    ox += pan.x; oy += pan.y
                                    clampOffsets()
                                }
                            }
                            .drawBehind {
                                val iw = bw * s0() * z
                                val ih = bh * s0() * z
                                drawIntoCanvas { c -> c.nativeCanvas.drawBitmap(src, null, RectF(ox, oy, ox + iw, oy + ih), paint) }
                            }
                    ) {}
                    Text("Zoom: ${(z * 100).toInt()}%", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    Slider(value = z, onValueChange = { zoomAround(it.coerceIn(1f, 6f), fw / 2f, fh / 2f); clampOffsets() }, valueRange = 1f..6f)
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onCancel) { Text("Annulla") }
                    OutlinedButton(onClick = {
                        val sc = s0() * z
                        val sx = (-ox / sc).coerceAtLeast(0f)
                        val sy = (-oy / sc).coerceAtLeast(0f)
                        val ex = ((fw - ox) / sc).coerceAtMost(bw)
                        val ey = ((fh - oy) / sc).coerceAtMost(bh)
                        val outW = 1600
                        val outH = (outW / aspect).toInt().coerceAtLeast(1)
                        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
                        Canvas(out).drawBitmap(src, Rect(sx.toInt(), sy.toInt(), ex.toInt(), ey.toInt()), Rect(0, 0, outW, outH), paint)
                        onDone(out)
                    }) { Text("Usa questo ritaglio") }
                }
            }
        }
    }
}
