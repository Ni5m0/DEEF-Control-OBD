package com.deef.control.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import com.deef.control.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Unico punto di lettura OBD, condiviso tra schermata telefono e schermata Android Auto. */
object ObdRepository {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    val values = MutableStateFlow<Map<String, Double>>(emptyMap())
    val status = MutableStateFlow("Non connesso")

    /** Vero finché la lettura è attiva (anche durante i tentativi di riconnessione). */
    val running = MutableStateFlow(false)

    @Volatile
    private var current: ElmConnection? = null

    /** Minimo e massimo raggiunti da ogni PID (valori grezzi, prima della conversione). */
    val minMax = MutableStateFlow<Map<String, Pair<Double, Double>>>(emptyMap())

    /** Ultimi valori di ogni PID (grezzi), per lo strumento a grafico. */
    val history = MutableStateFlow<Map<String, List<Double>>>(emptyMap())

    /** Registro di diagnostica mostrato nelle Impostazioni (ultime 150 righe). */
    val log = MutableStateFlow<List<String>>(emptyList())
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun addLog(msg: String) {
        val line = timeFmt.format(Date()) + " " + msg
        log.update { (it + line).takeLast(150) }
    }

    fun clearLog() {
        log.value = emptyList()
    }

    fun resetStats() {
        minMax.value = emptyMap()
        history.value = emptyMap()
    }

    @Synchronized
    fun ensureStarted(ctx: Context) {
        Settings.init(ctx.applicationContext)
        if (!Settings.autoConnect) return
        if (job?.isActive != true) start(ctx)
    }

    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
        current?.close() // chiude subito il Bluetooth, anche se una lettura è in corso
        current = null
        running.value = false
        status.value = "Non connesso"
    }

    @SuppressLint("MissingPermission")
    @Synchronized
    fun start(ctx: Context) {
        stop()
        val app = ctx.applicationContext
        Settings.init(app)
        val addr = Settings.deviceAddress
        if (addr.isBlank()) {
            status.value = "Scegli un adattatore nelle Impostazioni"
            return
        }
        running.value = true
        job = scope.launch {
            var startMethod = 0
            while (isActive) {
                var conn: ElmConnection? = null
                try {
                    val adapter = (app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                    conn = ElmConnection(adapter, adapter.getRemoteDevice(addr))
                    current = conn
                    conn.log = { addLog(it) }
                    addLog("Connessione a " + addr)
                    status.value = "Connessione..."
                    startMethod = conn.open(startMethod, Settings.protocol) { if (isActive) status.value = it }
                    status.value = "Connesso"
                    var hdr = ""
                    while (isActive) {
                        val pids = Settings.activePids()
                        if (pids.isEmpty()) {
                            delay(500)
                            continue
                        }
                        var got = 0
                        fun publish(pid: Pid, v: Double) {
                            got++
                            values.value = values.value + (pid.id to v)
                            history.value = history.value + (pid.id to ((history.value[pid.id] ?: emptyList()) + v).takeLast(150))
                            val old = minMax.value[pid.id]
                            val nv = if (old == null) (v to v) else (minOf(old.first, v) to maxOf(old.second, v))
                            minMax.value = minMax.value + (pid.id to nv)
                        }
                        for (pid in pids) {
                            if (pid.isCalc) continue
                            if (pid.header != hdr) {
                                conn.send("ATSH" + pid.header.ifBlank { "7DF" })
                                hdr = pid.header
                            }
                            val v = ElmConnection.decode(pid, conn.send(pid.command))
                            if (v != null) publish(pid, v)
                        }
                        // PID calcolati (es. potenza e coppia): ripetuto per rispettare le dipendenze
                        val calc = pids.filter { it.isCalc }
                        if (calc.isNotEmpty()) {
                            repeat(3) {
                                val named = values.value.mapKeys { it.key.uppercase() }
                                for (c in calc) {
                                    val v = Formula.eval(c.formula, emptyMap(), named)
                                    if (v != null) publish(c, v)
                                }
                            }
                        }
                        status.value = if (got > 0) "Connesso" else "Connesso, ma nessun dato dai PID (quadro acceso?)"
                    }
                } catch (e: Exception) {
                    if (e !is CarNotReady) startMethod = (startMethod + 1) % 3
                    addLog("ERRORE: " + (e.message ?: e.javaClass.simpleName))
                    val hint = if (e.message?.contains("Broken pipe") == true)
                        " (l'adattatore ha chiuso il collegamento: un'altra app, es. Torque o Car Scanner, lo sta usando?)"
                    else ""
                    if (isActive) status.value = "Errore: ${e.message ?: "sconosciuto"}$hint. Riprovo..."
                } finally {
                    conn?.close()
                }
                delay(3000)
            }
        }
    }
}
