package com.deef.control

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Mostra l'errore dopo un arresto. Gira in un processo separato, quindi funziona anche se l'app crasha all'avvio. */
class CrashActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val text = intent.getStringExtra("t") ?: "(nessun dettaglio)"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(24, 48, 24, 24)
        }
        root.addView(TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f
            this.text = "DEEF Control si è arrestata. Copia l'errore e mandalo:"
        })
        val tv = TextView(this).apply {
            setTextColor(Color.parseColor("#FF8A80")); textSize = 11f
            setTextIsSelectable(true); this.text = text
        }
        root.addView(ScrollView(this).apply { addView(tv) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(Button(this).apply {
            this.text = "Copia errore"
            setOnClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("errore", text))
            }
        })
        root.addView(Button(this).apply { this.text = "Chiudi"; setOnClickListener { finish() } })
        setContentView(root)
    }
}
