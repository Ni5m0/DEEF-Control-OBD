package com.deef.control.obd

/** Piccolo calcolatore per formule come "(A*256+B)/4-40". Variabili: A-H (byte della risposta). */
object Formula {
    /** named: valori di altri PID per nome (es. "MAF", "RPM"), usati dai PID calcolati. */
    fun eval(expr: String, vars: Map<Char, Double>, named: Map<String, Double> = emptyMap()): Double? = try {
        val r = P(expr.replace(" ", ""), vars, named).parse()
        if (r.isNaN() || r.isInfinite()) null else r
    } catch (e: Exception) {
        null
    }

    private class P(val s: String, val v: Map<Char, Double>, val named: Map<String, Double>) {
        var i = 0

        fun parse(): Double {
            val r = expr()
            if (i != s.length) error("residuo")
            return r
        }

        fun expr(): Double {
            var r = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val t = term()
                r = if (op == '+') r + t else r - t
            }
            return r
        }

        fun term(): Double {
            var r = factor()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]
                val f = factor()
                r = if (op == '*') r * f else r / f
            }
            return r
        }

        fun factor(): Double {
            if (i >= s.length) error("fine")
            val c = s[i]
            return when {
                c == '-' -> { i++; -factor() }
                c == '+' -> { i++; factor() }
                c == '(' -> {
                    i++
                    val r = expr()
                    if (i >= s.length || s[i] != ')') error(")")
                    i++
                    r
                }
                c.isDigit() || c == '.' -> {
                    val st = i
                    while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                    s.substring(st, i).toDouble()
                }
                c.isLetter() || c == '_' -> {
                    val st = i
                    while (i < s.length && (s[i].isLetterOrDigit() || s[i] == '_')) i++
                    val id = s.substring(st, i)
                    if (id.equals("S16", true) && i < s.length && s[i] == '(') {
                        // numero a 16 bit con segno: S16(A*256+B)
                        i++
                        val r = expr()
                        if (i >= s.length || s[i] != ')') error(")")
                        i++
                        if (r >= 32768.0) r - 65536.0 else r
                    } else if (id.length == 1 && id[0].uppercaseChar() in 'A'..'H') {
                        v[id[0].uppercaseChar()] ?: 0.0
                    } else {
                        named[id.uppercase()] ?: error("variabile")
                    }
                }
                else -> error("simbolo")
            }
        }
    }
}
