package com.deef.control

import android.Manifest
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.key
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.border
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import com.deef.control.car.SurfaceRender
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.deef.control.obd.AaTorqueImport
import com.deef.control.obd.BuiltInPids
import com.deef.control.obd.Formula
import com.deef.control.obd.ObdRepository
import com.deef.control.obd.BleBridgeConnection
import com.deef.control.obd.Pid
import com.deef.control.obd.TorqueImport
import com.deef.control.ui.Backgrounds
import com.deef.control.ui.BgStyle
import com.deef.control.ui.Conv
import com.deef.control.ui.GaugeCompose
import com.deef.control.ui.GaugeRenderer
import com.deef.control.ui.GaugeFont
import com.deef.control.ui.GaugeType
import com.deef.control.ui.GaugeTheme
import com.deef.control.ui.SlotConfig

class MainActivity : ComponentActivity() {
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Settings.init(this)
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
        ObdRepository.ensureStarted(this)
        DragTimer.refresh(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = Color.Black, contentColor = Color.White) { App() }
            }
        }
    }
}

// ---------------------------------------------------------------- struttura

@Composable
fun App() {
    var screen by remember { mutableIntStateOf(0) }
    var editing by remember { mutableIntStateOf(-1) }
    var tick by remember { mutableIntStateOf(0) }
    val status by ObdRepository.status.collectAsState()
    val running by ObdRepository.running.collectAsState()
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("DEEF", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Row {
                TextButton(onClick = { screen = 0; editing = -1 }) { Text("Dash", fontSize = 13.sp, maxLines = 1, softWrap = false) }
                TextButton(onClick = { screen = 2; editing = -1 }) { Text("Anteprima AA", fontSize = 13.sp, maxLines = 1, softWrap = false) }
                TextButton(onClick = { screen = 1; editing = -1 }) { Text("Impostazioni", fontSize = 13.sp, maxLines = 1, softWrap = false) }
            }
        }
        when {
            editing >= 0 -> Box(Modifier.weight(1f)) { SlotEditor(editing) { editing = -1; tick++ } }
            screen == 0 -> Box(Modifier.weight(1f)) { Dashboard { editing = it } }
            screen == 2 -> Box(Modifier.weight(1f)) { AaPreview { editing = it } }
            else -> Box(Modifier.weight(1f)) { MainSettings(tick) { editing = it } }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(status, fontSize = 12.sp, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = {
                if (running) {
                    Settings.autoConnect = false
                    ObdRepository.stop()
                } else {
                    Settings.autoConnect = true
                    ObdRepository.start(ctx)
                }
            }) { Text(if (running) "Disconnetti" else "Connetti") }
        }
    }
}

// ---------------------------------------------------------------- dashboard

@Composable
fun DashBackground(bg: BgStyle, darken: Int, blurRadius: Int) {
    val m = if (blurRadius > 0) Modifier.blur(blurRadius.dp) else Modifier
    Box(
        Modifier.fillMaxSize().clipToBounds().then(m).drawBehind {
            Backgrounds.draw(drawContext.canvas.nativeCanvas, size.width, size.height, bg, darken / 100f)
        }
    )
}

@Composable
fun Dashboard(onEdit: (Int) -> Unit) {
    val values by ObdRepository.values.collectAsState()
    val hists by ObdRepository.history.collectAsState()
    val stats by ObdRepository.minMax.collectAsState()
    var page by remember { mutableIntStateOf(Settings.visiblePage) }
    Settings.visiblePage = page
    val style = Settings.renderStyle()
    val gauges = Settings.pageGauges(page)
    val scale = Settings.scale
    val big = Settings.bigCenter && gauges.size == 3
    var editLayout by remember { mutableStateOf(false) }
    var layoutVer by remember { mutableIntStateOf(0) }
    val freeMode = editLayout || gauges.any { Settings.phoneLayout(it.slot) != null }

    Box(Modifier.fillMaxSize()) {
        DashBackground(Settings.background, Settings.darken, Settings.blur)
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                for (i in 0 until Settings.PAGES) {
                    FilterChip(selected = page == i, onClick = { page = i }, label = { Text("${i + 1}") })
                }
                Text(Settings.titles[page], fontSize = 14.sp, modifier = Modifier.padding(start = 8.dp))
                Spacer(Modifier.weight(1f))
                FilterChip(selected = editLayout, onClick = { editLayout = !editLayout }, label = { Text(if (editLayout) "Fine" else "Layout") })
            }
            BoxWithConstraints(Modifier.fillMaxSize().padding(8.dp)) {
                if (freeMode) {
                    val wPx = constraints.maxWidth.toFloat()
                    val hPx = constraints.maxHeight.toFloat()
                    val dens = androidx.compose.ui.platform.LocalDensity.current
                    var sel by remember(page) { mutableIntStateOf(-1) }
                    fun cell(i: Int): FloatArray {
                        val g = gauges[i]
                        val o = Settings.phoneLayout(g.slot)
                        if (o != null) return floatArrayOf(o[0], o[1], o[2])
                        val n = gauges.size
                        val side = minOf(wPx / n, hPx) * 0.92f / hPx
                        return floatArrayOf((i + 0.5f) / n, 0.5f, side)
                    }
                    key(layoutVer) {
                        Box(Modifier.fillMaxSize().clipToBounds()) {
                            gauges.forEachIndexed { i, g ->
                                val c = cell(i)
                                val sidePx = c[2] * hPx
                                val xPx = c[0] * wPx - sidePx / 2
                                val yPx = c[1] * hPx - sidePx / 2
                                val sideDp = with(dens) { sidePx.toDp() }
                                Box(
                                    Modifier
                                        .offset(with(dens) { xPx.toDp() }, with(dens) { yPx.toDp() })
                                        .size(sideDp)
                                        .then(if (editLayout && sel == i) Modifier.border(2.dp, Color(0xFF00E5FF)) else Modifier)
                                        .pointerInput(editLayout, i, layoutVer) {
                                            if (editLayout) {
                                                detectDragGestures(
                                                    onDragStart = { sel = i },
                                                    onDrag = { ch, d ->
                                                        ch.consume()
                                                        val cc = cell(i)
                                                        Settings.setPhoneLayout(g.slot, floatArrayOf(
                                                            (cc[0] + d.x / wPx).coerceIn(0f, 1f),
                                                            (cc[1] + d.y / hPx).coerceIn(0f, 1f), cc[2]))
                                                        layoutVer++
                                                    })
                                            }
                                        }
                                        .pointerInput(editLayout, i) {
                                            detectTapGestures(
                                                onTap = { if (editLayout) sel = i else onEdit(g.slot) },
                                                onLongPress = { onEdit(g.slot) })
                                        }
                                ) {
                                    GaugeCompose(g, values[g.pidId], stats[g.pidId], hists[g.pidId], style, Modifier.fillMaxSize())
                                }
                            }
                        }
                    }
                    if (editLayout) {
                        Column(Modifier.align(Alignment.BottomCenter).background(Color(0xCC000000)).padding(8.dp)) {
                            val i = sel
                            if (i in gauges.indices) {
                                val g = gauges[i]
                                val cur = cell(i)
                                Text("Dimensione di " + g.label + " (" + (cur[2] * 100).toInt() + "%)", fontSize = 12.sp)
                                Slider(
                                    value = cur[2].coerceIn(0.15f, 1.1f), valueRange = 0.15f..1.1f,
                                    onValueChange = {
                                        Settings.setPhoneLayout(g.slot, floatArrayOf(cur[0], cur[1], it)); layoutVer++
                                    })
                            } else Text("Tocca un quadrante, trascinalo per spostarlo", fontSize = 12.sp)
                            OutlinedButton(onClick = {
                                gauges.forEach { Settings.setPhoneLayout(it.slot, null) }; layoutVer++
                            }) { Text("Layout automatico") }
                        }
                    }
                } else if (maxWidth > maxHeight) {
                    // orizzontale: quadranti affiancati (quello centrale più grande, se attivo)
                    Row(
                        Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        gauges.forEachIndexed { i, g ->
                            val wgt = (if (big && i == 1) 1.35f else 1f) * g.size
                            Box(Modifier.weight(wgt).aspectRatio(1f)) {
                                GaugeCompose(g, values[g.pidId], stats[g.pidId], hists[g.pidId], style, Modifier.fillMaxSize().clickable { onEdit(g.slot) })
                            }
                        }
                    }
                } else {
                    // verticale: quadranti in colonna
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        gauges.forEachIndexed { i, g ->
                            val f = ((if (big && i != 1) scale * 0.8f else scale) * g.size).coerceAtMost(1f)
                            GaugeCompose(g, values[g.pidId], stats[g.pidId], hists[g.pidId], style, Modifier.fillMaxWidth(f).aspectRatio(1f).clickable { onEdit(g.slot) })
                        }
                    }
                }
            }
        }
        if (Settings.dragEnabled) DragCard(Modifier.align(Alignment.BottomCenter).padding(8.dp))
    }
}

@Composable
fun DragCard(modifier: Modifier = Modifier) {
    val st by DragTimer.state.collectAsState()
    var from by remember { mutableIntStateOf(Settings.dragFrom) }
    var to by remember { mutableIntStateOf(Settings.dragTo) }
    fun set(f: Int, t: Int) { from = f; to = t; Settings.dragFrom = f; Settings.dragTo = t; DragTimer.reset() }
    Surface(modifier, color = Color(0xCC000000), shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0 to 100, 100 to 200, 0 to 200).forEach { (f, t) ->
                    FilterChip(selected = from == f && to == t, onClick = { set(f, t) }, label = { Text("$f-$t") })
                }
            }
            Text("GPS " + (st.speed?.let { "%.0f".format(it) } ?: "--") + " km/h   ·   " + from + "-" + to,
                fontSize = 14.sp)
            Text(DragTimer.phaseText(st), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Ultimo " + DragTimer.fmt(st.lastMs) + "   Best " + DragTimer.fmt(st.bestMs), fontSize = 13.sp)
                TextButton(onClick = { DragTimer.reset() }) { Text("Reset") }
            }
        }
    }
}

@Composable
fun AaPreview(onEdit: (Int) -> Unit) {
    val values by ObdRepository.values.collectAsState()
    val hists by ObdRepository.history.collectAsState()
    val stats by ObdRepository.minMax.collectAsState()
    val drag by DragTimer.state.collectAsState()
    val status by ObdRepository.status.collectAsState()
    var page by remember { mutableIntStateOf(Settings.visiblePage) }
    Settings.visiblePage = page
    val style = Settings.renderStyle(compact = true)
    val gauges = Settings.pageGauges(page)
    val pane = Settings.aaLayout == "PANE"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp)) {
        Text("Anteprima di Android Auto. Tieni premuto un manometro per modificarlo.", fontSize = 13.sp)
        Column(
            Modifier.fillMaxWidth().padding(top = 8.dp)
                .background(Color(0xFF12151A), androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                .padding(10.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("DEEF · " + status.take(34), fontSize = 13.sp, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { page = (page + 1) % Settings.PAGES }) { Text(Settings.titles[page] + " >") }
            }
            if (gauges.isEmpty()) Text("Pagina vuota: abilita un quadro (tieni premuto) o configurala nelle Impostazioni.", Modifier.padding(8.dp))
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                gauges.forEach { g ->
                    Column(Modifier.weight(1f)) {
                        GaugeCompose(
                            g, values[g.pidId], stats[g.pidId], hists[g.pidId], style,
                            Modifier.fillMaxWidth().aspectRatio(1f).pointerInput(g.slot) {
                                detectTapGestures(onLongPress = { onEdit(g.slot) })
                            }
                        )
                        Text(g.label, fontSize = 12.sp)
                    }
                }
            }
            if (pane) {
                gauges.take(if (Settings.dragEnabled) 3 else 4).forEach { g ->
                    val v = values[g.pidId]?.let { g.convert(it) }
                    Text(g.label + "   " + GaugeRenderer.format(v, g) + " " + g.unit, Modifier.padding(top = 6.dp))
                }
            }
            if (Settings.dragEnabled) {
                Text("Drag " + Settings.dragFrom + "-" + Settings.dragTo + " · " + DragTimer.phaseText(drag) + " · best " + DragTimer.fmt(drag.bestMs),
                    Modifier.padding(top = 6.dp))
            }
        }
        // Schermo intero con le dimensioni reali dell'auto (rilevate al primo uso, altrimenti 800x480)
        val cw = Settings.carW.takeIf { it > 0 } ?: 800
        val ch = Settings.carH.takeIf { it > 0 } ?: 480
        val vis = Settings.carVisible.split(",").mapNotNull { it.toIntOrNull() }.takeIf { it.size == 4 }
            ?.let { android.graphics.Rect(it[0], it[1], it[2], it[3]) }
            ?: android.graphics.Rect(0, 0, (cw * 0.62f).toInt(), ch)
        Text(
            "Schermo intero: ${cw}x$ch" + (if (Settings.carW > 0) " (misure reali della tua auto)" else " (misure stimate: apri lo schermo intero in auto una volta)"),
            fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp),
        )
        val fullGauges = Settings.pageGauges(page)
        var sc by remember { mutableFloatStateOf(Settings.surfaceScale.toFloat()) }
        var boxW by remember { mutableIntStateOf(0) }
        var boxH by remember { mutableIntStateOf(0) }
        fun scaledArea() = android.graphics.Rect(
            (vis.left * boxW / cw.toFloat()).toInt(), (vis.top * boxH / ch.toFloat()).toInt(),
            (vis.right * boxW / cw.toFloat()).toInt(), (vis.bottom * boxH / ch.toFloat()).toInt(),
        )
        var sel by remember { mutableIntStateOf(-1) }      // slot selezionato
        var tick by remember { mutableIntStateOf(0) }       // forza il ridisegno dopo spostamenti
        fun hit(off: androidx.compose.ui.geometry.Offset): FloatArray? =
            SurfaceRender.cells(fullGauges, scaledArea(), Settings.dragEnabled).firstOrNull { c ->
                off.x in c[1]..(c[1] + c[3]) && off.y in c[2]..(c[2] + c[3])
            }
        Box(
            Modifier.fillMaxWidth().padding(top = 4.dp).aspectRatio(cw.toFloat() / ch).clipToBounds()
                .onSizeChanged { boxW = it.width; boxH = it.height }
                .pointerInput(page, fullGauges.size) {
                    detectTapGestures(
                        onTap = { off -> sel = hit(off)?.let { fullGauges[it[0].toInt()].slot } ?: -1 },
                        onLongPress = { off -> hit(off)?.let { onEdit(fullGauges[it[0].toInt()].slot) } },
                    )
                }
                .pointerInput(page, fullGauges.size) {
                    // trascina un quadrante per spostarlo (posizione libera)
                    var dragSlot = -1
                    var cx = 0f; var cy = 0f; var side = 0f
                    detectDragGestures(
                        onDragStart = { off ->
                            val c = hit(off)
                            if (c != null) {
                                dragSlot = fullGauges[c[0].toInt()].slot; sel = dragSlot
                                cx = c[1] + c[3] / 2f; cy = c[2] + c[3] / 2f; side = c[3]
                            } else dragSlot = -1
                        },
                        onDrag = { change, delta ->
                            if (dragSlot >= 0) {
                                change.consume()
                                cx += delta.x; cy += delta.y
                                val ar = scaledArea()
                                Settings.setSurfLayout(dragSlot, floatArrayOf(
                                    ((cx - ar.left) / ar.width()).coerceIn(0f, 1f),
                                    ((cy - ar.top) / ar.height()).coerceIn(0f, 1f),
                                    side / ar.height(),
                                ))
                                tick++
                            }
                        },
                    )
                }
                .drawBehind {
                    values.size; hists.size; stats.size; drag.elapsedMs; sc; tick // si ridisegna quando arrivano dati nuovi
                    val nc = drawContext.canvas.nativeCanvas
                    SurfaceRender.draw(nc, size.width.toInt(), size.height.toInt(), scaledArea(), page)
                    if (sel >= 0) {
                        SurfaceRender.cells(fullGauges, scaledArea(), Settings.dragEnabled).forEach { c ->
                            if (fullGauges[c[0].toInt()].slot == sel) {
                                val pt = android.graphics.Paint().apply {
                                    this.style = android.graphics.Paint.Style.STROKE; strokeWidth = 4f
                                    color = android.graphics.Color.rgb(120, 200, 255)
                                }
                                nc.drawRect(c[1], c[2], c[1] + c[3], c[2] + c[3], pt)
                            }
                        }
                    }
                }
        )
        Text("Tocca un quadrante per selezionarlo, trascinalo per spostarlo, tienilo premuto per cambiare PID e stile.", fontSize = 12.sp)
        val selG = fullGauges.firstOrNull { it.slot == sel }
        if (selG != null) {
            val ar = scaledArea()
            val curSide = SurfaceRender.cells(fullGauges, ar, Settings.dragEnabled)
                .firstOrNull { fullGauges[it[0].toInt()].slot == sel }?.get(3) ?: 0f
            var sizePct by remember(sel, tick) { mutableFloatStateOf((curSide / ar.height().coerceAtLeast(1) * 100f).coerceIn(15f, 110f)) }
            SliderRow("Dimensione di " + selG.label + " (%)", sizePct, 15f..110f, { v ->
                sizePct = v
                val c = SurfaceRender.cells(fullGauges, ar, Settings.dragEnabled).first { fullGauges[it[0].toInt()].slot == sel }
                val fx = ((c[1] + c[3] / 2f) - ar.left) / ar.width()
                val fy = ((c[2] + c[3] / 2f) - ar.top) / ar.height()
                Settings.setSurfLayout(sel, floatArrayOf(fx, fy, v / 100f)); tick++
            }) {}
            OutlinedButton(onClick = { Settings.setSurfLayout(sel, null); tick++ }) { Text("Posizione e dimensione automatiche") }
        }
        var splitOn by remember { mutableStateOf(Settings.splitText) }
        var splitV by remember { mutableFloatStateOf(Settings.splitPct.toFloat()) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = splitOn, onCheckedChange = { splitOn = it; Settings.splitText = it })
            Text("  Pagina divisa: quadranti a sinistra, valori scritti a destra", fontSize = 13.sp)
        }
        if (splitOn) SliderRow("Spazio ai quadranti (%)", splitV, 30f..90f, { splitV = it; Settings.splitPct = it.toInt() }) {}
        SliderRow("Dimensione quadranti a schermo intero (%)", sc, 40f..140f, { sc = it; Settings.surfaceScale = it.toInt() }) {}
        Text("Sopra il 100% i quadranti possono finire sotto la scheda musicale di Android Auto: regola guardando l'anteprima e poi in auto.", fontSize = 12.sp)
        Text("Layout: " + (if (pane) "pannello grande" else "griglia") + " (si cambia in Impostazioni → Layout su Android Auto). L'aspetto reale può differire leggermente.", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

// ---------------------------------------------------------------- componenti comuni

@SuppressLint("MissingPermission")
fun bondedDevices(ctx: Context): List<Pair<String, String>> = try {
    val a = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    a?.bondedDevices?.map { (it.name ?: "?") to it.address } ?: emptyList()
} catch (e: SecurityException) {
    emptyList()
}

fun parseNum(s: String): Double? = s.replace(',', '.').trim().toDoubleOrNull()

fun fmtNum(d: Double): String = if (d % 1.0 == 0.0) d.toLong().toString() else d.toString()

@Composable
fun <T> ChipRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) })
        }
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SliderRow(
    title: String, value: Float, range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit, onFinish: () -> Unit,
) {
    Column {
        Text("$title: ${value.toInt()}", fontSize = 13.sp)
        Slider(value = value, onValueChange = onChange, valueRange = range, onValueChangeFinished = onFinish)
    }
}

@Composable
fun Field(label: String, value: String, modifier: Modifier = Modifier.fillMaxWidth(), onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, label = { Text(label) }, singleLine = true, modifier = modifier)
}

@Composable
fun SlotPicker(all: List<Pid>, current: String, modifier: Modifier, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val label = all.find { it.id == current }?.shortName ?: "—"
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(label, maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("— vuoto —") }, onClick = { onPick("-"); open = false })
            all.forEach { pid ->
                DropdownMenuItem(text = { Text(pid.name) }, onClick = { onPick(pid.id); open = false })
            }
        }
    }
}

// ---------------------------------------------------------------- impostazioni

@Composable
fun SettingsScreen() {
    var editing by remember { mutableIntStateOf(-1) }
    var tick by remember { mutableIntStateOf(0) }
    if (editing >= 0) {
        SlotEditor(editing) { editing = -1; tick++ }
    } else {
        MainSettings(tick) { editing = it }
    }
}

@Composable
fun MainSettings(tick: Int, onEdit: (Int) -> Unit) {
    val ctx = LocalContext.current
    var theme by remember { mutableStateOf(Settings.theme) }
    var font by remember { mutableStateOf(Settings.font) }
    var bg by remember { mutableStateOf(Settings.background) }
    var darken by remember { mutableFloatStateOf(Settings.darken.toFloat()) }
    var blurR by remember { mutableFloatStateOf(Settings.blur.toFloat()) }
    var opacity by remember { mutableFloatStateOf(Settings.opacity.toFloat()) }
    var bigCenter by remember { mutableStateOf(Settings.bigCenter) }
    var mmBelow by remember { mutableStateOf(Settings.minMaxBelow) }
    var perPage by remember { mutableIntStateOf(Settings.perPage) }
    var aaLayout by remember { mutableStateOf(Settings.aaLayout) }
    var betaFull by remember { mutableStateOf(Settings.betaFull) }
    var scale by remember { mutableFloatStateOf(Settings.scale) }
    var addr by remember { mutableStateOf(Settings.deviceAddress) }
    val titles = remember { mutableStateListOf<String>().apply { addAll(Settings.titles) } }
    var custom by remember { mutableStateOf(Settings.customPids) }
    var localTick by remember { mutableIntStateOf(0) }
    val cfgs = remember(tick, localTick) { Settings.slotConfigs }
    var devices by remember { mutableStateOf(bondedDevices(ctx)) }
    fun hasBt() = Build.VERSION.SDK_INT < 31 ||
        (ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED)
    var btOk by remember { mutableStateOf(hasBt()) }
    val btPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        btOk = hasBt(); devices = bondedDevices(ctx)
    }
    var importMsg by remember { mutableStateOf("") }
    var protocol by remember { mutableStateOf(Settings.protocol) }
    var dragOn by remember { mutableStateOf(Settings.dragEnabled) }
    var dFrom by remember { mutableIntStateOf(Settings.dragFrom) }
    var dTo by remember { mutableIntStateOf(Settings.dragTo) }
    var fFromTxt by remember { mutableStateOf(Settings.dragFrom.toString()) }
    var fToTxt by remember { mutableStateOf(Settings.dragTo.toString()) }
    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { DragTimer.refresh(ctx) }
    val logLines by ObdRepository.log.collectAsState()
    val clipboard = LocalClipboardManager.current

    var fName by remember { mutableStateOf("") }
    var fShort by remember { mutableStateOf("") }
    var fUnit by remember { mutableStateOf("") }
    var fCmd by remember { mutableStateOf("") }
    var fFormula by remember { mutableStateOf("A") }
    var fHeader by remember { mutableStateOf("") }
    var fMin by remember { mutableStateOf("0") }
    var fMax by remember { mutableStateOf("100") }
    var fWarn by remember { mutableStateOf("90") }
    var formError by remember { mutableStateOf("") }

    val all = BuiltInPids.all + custom

    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching {
                ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            }.getOrNull()
            if (text == null) {
                importMsg = "Impossibile leggere il file"
            } else {
                val (list, skipped) = TorqueImport.parseCsv(text)
                val existing = custom.map { it.command + it.name }.toSet()
                val add = list.filter { (it.command + it.name) !in existing }
                custom = custom + add
                Settings.customPids = custom
                importMsg = "PID importati: ${add.size}. Scartati: $skipped (riga non valida o formula non supportata)."
            }
        }
    }

    val pbLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val bytes = runCatching { ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }.getOrNull()
            if (bytes == null) {
                importMsg = "Impossibile leggere il file"
            } else {
                val pages = AaTorqueImport.parse(bytes)
                val newCustom = custom.toMutableList()
                val list = Settings.slotConfigs.toMutableList()
                var used = 0
                var skipped = 0
                pages.take(Settings.PAGES).forEachIndexed { pg, gs ->
                    gs.take(Settings.SLOTS).forEachIndexed { s, g ->
                        val pid = AaTorqueImport.toPid(g)
                        if (pid == null) {
                            skipped++
                        } else {
                            if (BuiltInPids.all.none { it.id == pid.id } && newCustom.none { it.id == pid.id }) {
                                newCustom.add(pid)
                            }
                            list[pg * Settings.SLOTS + s] = SlotConfig(pidId = pid.id, label = g.label)
                            used++
                        }
                    }
                }
                custom = newCustom
                Settings.customPids = custom
                Settings.slotConfigs = list
                localTick++
                importMsg = if (pages.isEmpty()) "Nessun quadrante riconosciuto nel file"
                else "Quadranti importati: $used. Non supportati: $skipped."
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // ----- Aspetto
        item { Text("Aspetto", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item { Text("Tema") }
        item { ChipRow(GaugeTheme.entries, theme, { it.label }) { theme = it; Settings.theme = it } }
        item { Text("Carattere dei numeri") }
        item { ChipRow(GaugeFont.entries, font, { it.label }) { font = it; Settings.font = it } }
        item { Text("Sfondo") }
        item { ChipRow(BgStyle.entries, bg, { it.label }) { bg = it; Settings.background = it } }
        item { SliderRow("Scurisci sfondo", darken, 0f..100f, { darken = it }) { Settings.darken = darken.toInt() } }
        item { SliderRow("Sfoca sfondo (Android 12+)", blurR, 0f..20f, { blurR = it }) { Settings.blur = blurR.toInt() } }
        item { SliderRow("Opacità indicatori", opacity, 0f..100f, { opacity = it }) { Settings.opacity = opacity.toInt() } }
        item { SwitchRow("Indicatore centrale più grande", bigCenter) { bigCenter = it; Settings.bigCenter = it } }
        item { SwitchRow("Min/Max sotto l'indicatore", mmBelow) { mmBelow = it; Settings.minMaxBelow = it } }
        item { Text("Numero di quadri per pagina") }
        item { ChipRow(listOf(1, 2, 3), perPage, { it.toString() }) { perPage = it; Settings.perPage = it } }
        item { Text("Layout su Android Auto") }
        item { ChipRow(listOf("SURFACE", "PANE", "GRID"), aaLayout, { when (it) { "SURFACE" -> "Schermo intero"; "PANE" -> "Pannello"; else -> "Griglia" } }) { aaLayout = it; Settings.aaLayout = it } }
        item { Text("Nella Dash tocca un quadrante per modificarlo.", fontSize = 12.sp) }

        item { Text("Drag GPS (cronometro 0-100, 100-200…)", fontWeight = FontWeight.Bold) }
        item {
            SwitchRow("Attiva rilevamento drag con GPS", dragOn) {
                dragOn = it; Settings.dragEnabled = it
                if (it && !DragTimer.hasPermission(ctx)) locLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                else DragTimer.refresh(ctx)
            }
        }
        item { Text("Da / A (km/h)") }
        item {
            ChipRow(listOf(0 to 100, 100 to 200, 0 to 200, -1 to -1), if (dFrom == 0 && dTo == 100) 0 to 100 else if (dFrom == 100 && dTo == 200) 100 to 200 else if (dFrom == 0 && dTo == 200) 0 to 200 else -1 to -1,
                { if (it.first < 0) "Personalizzato" else "${it.first}-${it.second}" }) {
                if (it.first >= 0) { dFrom = it.first; dTo = it.second; Settings.dragFrom = dFrom; Settings.dragTo = dTo; fFromTxt = dFrom.toString(); fToTxt = dTo.toString(); DragTimer.reset() }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("Da km/h", fFromTxt, Modifier.weight(1f)) { fFromTxt = it; parseNum(it)?.toInt()?.let { v -> if (v >= 0) { dFrom = v; Settings.dragFrom = v; DragTimer.reset() } } }
                Field("A km/h", fToTxt, Modifier.weight(1f)) { fToTxt = it; parseNum(it)?.toInt()?.let { v -> if (v > 0) { dTo = v; Settings.dragTo = v; DragTimer.reset() } } }
            }
        }
        item { OutlinedButton(onClick = { DragTimer.clearBest() }) { Text("Azzera tempi di questo intervallo") } }
        item { Text("Il GPS aggiorna ~1 volta al secondo: tempi stimati (±0,1–0,3 s). Usa solo su strada chiusa o pista.", fontSize = 12.sp) }
        item {
            Column {
                Text("Grandezza quadranti (telefono in verticale): ${(scale * 100).toInt()}%", fontSize = 13.sp)
                Slider(
                    value = scale, onValueChange = { scale = it },
                    onValueChangeFinished = { Settings.scale = scale }, valueRange = 0.5f..1f,
                )
            }
        }

        // ----- Pagine e quadri
        item { Text("Pagine e quadri", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        items((0 until Settings.PAGES).toList()) { pg ->
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Field("Titolo pagina ${pg + 1}", titles[pg]) { t ->
                    titles[pg] = t
                    Settings.setTitle(pg, t)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (s in 0 until Settings.SLOTS) {
                        val idx = pg * Settings.SLOTS + s
                        val c = cfgs[idx]
                        val name = all.find { it.id == c.pidId }?.shortName ?: "—"
                        OutlinedButton(onClick = { onEdit(idx) }, modifier = Modifier.weight(1f)) {
                            Text(name + if (!c.enabled) " (off)" else "", maxLines = 1, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        item { Text("Tocca un quadro per modificarne PID, etichetta, unità, allarmi e altro.", fontSize = 12.sp) }
        item {
            OutlinedButton(onClick = {
                Settings.applyS1Preset()
                titles.clear()
                titles.addAll(Settings.titles)
                localTick++
            }) { Text("Applica layout S1 (giri, turbo, H2O, olio, EGT, HP/Nm)") }
        }
        item { OutlinedButton(onClick = { ObdRepository.resetStats() }) { Text("Azzera min/max") } }

        // ----- Importa
        item { Text("Importa", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { csvLauncher.launch(arrayOf("*/*")) }) { Text("PID da CSV (Torque)") }
                OutlinedButton(onClick = { pbLauncher.launch(arrayOf("*/*")) }) { Text("Pagine da .pb") }
            }
        }
        if (importMsg.isNotEmpty()) item { Text(importMsg, fontSize = 12.sp) }

        // ----- Libreria PID
        item { Text("Libreria PID", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item {
            Text(
                "La libreria interna contiene i PID standard (motore, temperature, aria e turbo, carburante, " +
                    "tensione) e quelli dell'Audi S1 (pressione e temperatura olio). Si scelgono dall'editor del " +
                    "quadro, con ricerca. Quelli inseriti a mano compaiono sotto Personalizzati.",
                fontSize = 12.sp,
            )
        }

        // ----- PID personalizzati
        if (custom.isNotEmpty()) {
            item { Text("PID personalizzati", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            items(custom) { pid ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${pid.name} (${pid.unit}) ${pid.command}", modifier = Modifier.weight(1f), fontSize = 13.sp)
                    TextButton(onClick = {
                        custom = custom.filter { it.id != pid.id }
                        Settings.customPids = custom
                        val l = Settings.slotConfigs.map { if (it.pidId == pid.id) it.copy(pidId = "-") else it }
                        Settings.slotConfigs = l
                        localTick++
                    }) { Text("Elimina") }
                }
            }
        }

        item { Text("Nuovo PID personalizzato", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item { Field("Nome", fName) { fName = it } }
        item { Field("Nome corto (es. EGT)", fShort) { fShort = it } }
        item { Field("Unità (es. °C, bar)", fUnit) { fUnit = it } }
        item { Field("Comando (es. 010C, 221234 o CALC)", fCmd) { fCmd = it } }
        item { Field("Header ECU (opzionale, es. 7E0)", fHeader) { fHeader = it } }
        item { Field("Formula con A,B,C... (es. (A*256+B)/4)", fFormula) { fFormula = it } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("Min", fMin, Modifier.weight(1f)) { fMin = it }
                Field("Max", fMax, Modifier.weight(1f)) { fMax = it }
                Field("Allarme", fWarn, Modifier.weight(1f)) { fWarn = it }
            }
        }
        item {
            Column {
                if (formError.isNotEmpty()) Text(formError, color = Color(0xFFFF5252), fontSize = 12.sp)
                Button(onClick = {
                    val mn = parseNum(fMin)
                    val mx = parseNum(fMax)
                    val wn = parseNum(fWarn)
                    val isCalc = fCmd.trim().equals("CALC", ignoreCase = true)
                    val cmdOk = isCalc || (fCmd.length >= 4 && fCmd.all { it.isDigit() || it.uppercaseChar() in 'A'..'F' })
                    val named = (BuiltInPids.all + custom).associate { it.id.uppercase() to 1.0 }
                    val fOk = Formula.eval(fFormula, ('A'..'H').associateWith { 1.0 }, named) != null
                    val hdrOk = fHeader.isEmpty() || fHeader.all { it.isDigit() || it.uppercaseChar() in 'A'..'F' }
                    formError = when {
                        fName.isBlank() -> "Inserisci un nome"
                        !cmdOk -> "Comando non valido (cifre esadecimali, almeno 4, oppure CALC per un valore calcolato)"
                        !hdrOk -> "Header non valido (solo cifre esadecimali)"
                        !fOk -> "Formula non valida"
                        mn == null || mx == null || wn == null || mx <= mn -> "Min/Max/Allarme non validi"
                        else -> ""
                    }
                    if (formError.isEmpty()) {
                        val pid = Pid(
                            "C_" + System.currentTimeMillis(), fName.trim(),
                            fShort.ifBlank { fName }.trim().take(8), fUnit.trim(),
                            fCmd.uppercase(), fFormula.trim(), mn!!, mx!!, wn!!, true, fHeader.uppercase(),
                        )
                        custom = custom + pid
                        Settings.customPids = custom
                        fName = ""; fShort = ""; fUnit = ""; fCmd = ""; fHeader = ""
                    }
                }) { Text("Aggiungi PID") }
            }
        }

        // ----- Adattatore
        // ----- Diagnostica
        item { Text("Diagnostica connessione", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item {
            var showLog by remember { mutableStateOf(false) }
            var pendingCsv by remember { mutableStateOf(false) }
            val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
                if (uri != null) try {
                    val body = if (pendingCsv)
                        "n;riga\n" + logLines.mapIndexed { i, l -> "${i + 1};\"" + l.replace("\"", "'") + "\"" }.joinToString("\n")
                    else logLines.joinToString("\n")
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(body.toByteArray()) }
                } catch (_: Exception) { }
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showLog = !showLog }) {
                    Text(if (showLog) "Nascondi registro" else "Visualizza registro")
                }
                if (showLog) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { clipboard.setText(AnnotatedString(logLines.joinToString("\n"))) }) { Text("Copia") }
                        OutlinedButton(onClick = { pendingCsv = false; saveLauncher.launch("deef-registro.txt") }) { Text("TXT") }
                        OutlinedButton(onClick = { pendingCsv = true; saveLauncher.launch("deef-registro.csv") }) { Text("CSV") }
                        OutlinedButton(onClick = { ObdRepository.clearLog() }) { Text("Svuota") }
                    }
                    Text(
                        if (logLines.isEmpty()) "Nessuna attività."
                        else logLines.takeLast(40).joinToString("\n"),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                    )
                }
            }
        }
        item {
            var crash by remember { mutableStateOf(Settings.lastCrash) }
            if (crash.isNotEmpty()) {
                Column {
                    Text("Ultimo arresto dell'app:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(crash.take(900), fontSize = 10.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { clipboard.setText(AnnotatedString(crash)) }) { Text("Copia errore") }
                        OutlinedButton(onClick = { Settings.lastCrash = ""; crash = "" }) { Text("Cancella") }
                    }
                }
            }
        }

        item { Text("Protocollo OBD", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item {
            ChipRow(
                listOf("6", "0", "7", "8"), protocol,
                {
                    when (it) {
                        "6" -> "CAN 11 bit 500k (Audi/VAG)"
                        "0" -> "Automatico"
                        "7" -> "CAN 29 bit 500k"
                        else -> "CAN 11 bit 250k"
                    }
                },
            ) { protocol = it; Settings.protocol = it }
        }
        item { Text("Dopo averlo cambiato premi Disconnetti e Connetti.", fontSize = 12.sp) }

        if (!btOk) item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Permesso Bluetooth mancante: senza non si vedono né gli adattatori associati né i dongle BLE.",
                    fontSize = 13.sp, color = Color(0xFFFFB74D))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        btPerm.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN))
                    }) { Text("Concedi permesso") }
                    OutlinedButton(onClick = {
                        ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            android.net.Uri.parse("package:" + ctx.packageName)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                    }) { Text("Apri impostazioni app") }
                }
                Text("Se il pulsante non fa comparire nulla: Impostazioni app → Autorizzazioni → Dispositivi nelle vicinanze → Consenti.",
                    fontSize = 11.sp)
            }
        }
        // ----- Dongle BLE (ESP32, come per Simos Tools)
        item { Text("Dongle BLE Simos (ESP32)", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item {
            var bleOn by remember { mutableStateOf(Settings.bleMode) }
            var bleName by remember { mutableStateOf(Settings.bleName) }
            var found by remember { mutableStateOf(listOf<Pair<String, String>>()) }
            var scanning by remember { mutableStateOf(false) }
            fun doScan() {
                found = emptyList(); scanning = true
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ scanning = false }, 10000)
                BleBridgeConnection.scan(ctx, 8000, { n, a -> found = found + (n to a) }, { scanning = false })
            }
            val scanPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
                btOk = hasBt(); devices = bondedDevices(ctx)
                if (hasBt()) doScan()
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = bleOn, onCheckedChange = {
                        bleOn = it; Settings.bleMode = it
                        if (Settings.autoConnect && ObdRepository.running.value) ObdRepository.start(ctx)
                    })
                    Text("  Usa il dongle BLE invece dell'ELM327", fontSize = 13.sp)
                }
                Text("Solo lettura. Dongle scelto: " + (if (bleName.isBlank()) "nessuno" else bleName), fontSize = 12.sp)
                OutlinedButton(enabled = !scanning, onClick = {
                    if (!hasBt()) scanPerm.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN))
                    else doScan()
                }) { Text(if (scanning) "Ricerca in corso..." else "Cerca dongle BLE") }
                found.sortedByDescending { it.first.contains("ISOTP", true) || it.first.contains("BLE", true) }.forEach { d ->
                    TextButton(onClick = {
                        Settings.bleAddress = d.second; Settings.bleName = d.first + " (" + d.second + ")"
                        bleName = Settings.bleName
                        if (bleOn) { Settings.autoConnect = true; ObdRepository.start(ctx) }
                    }) { Text(d.first + "  " + d.second) }
                }
            }
        }

        item { Text("Adattatore OBD (Bluetooth già associato)", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        if (devices.isEmpty()) {
            item { Text("Nessun dispositivo associato (o permesso Bluetooth negato).", fontSize = 12.sp) }
        }
        items(devices) { d ->
            TextButton(onClick = {
                Settings.deviceAddress = d.second
                addr = d.second
                Settings.autoConnect = true
                ObdRepository.start(ctx)
            }) { Text(d.first + if (d.second == addr) "  ✓" else "") }
        }

    }
}

// ---------------------------------------------------------------- editor del singolo quadro

@Composable
fun SlotEditor(idx: Int, onBack: () -> Unit) {
    val all = Settings.allPids()
    var c by remember { mutableStateOf(Settings.slotConfigs[idx]) }
    fun upd(n: SlotConfig) {
        c = n
        Settings.setSlot(idx, n)
    }
    var tLabel by remember { mutableStateOf(c.label) }
    var tUnit by remember { mutableStateOf(c.unit) }
    var tYel by remember { mutableStateOf(c.yellow?.let { fmtNum(it) } ?: "") }
    var tRed by remember { mutableStateOf(c.red?.let { fmtNum(it) } ?: "") }
    var tMin by remember { mutableStateOf(c.min?.let { fmtNum(it) } ?: "") }
    var tMax by remember { mutableStateOf(c.max?.let { fmtNum(it) } ?: "") }
    var tConv by remember { mutableStateOf(c.convFormula) }
    var tLow by remember { mutableStateOf(c.low?.let { fmtNum(it) } ?: "") }
    var sz by remember { mutableFloatStateOf(c.size) }
    val colors = listOf(
        "Tema" to 0L, "Rosso" to 0xFFE0201CL, "Arancio" to 0xFFFFB000L, "Giallo" to 0xFFFFEB3BL,
        "Verde" to 0xFF3DDC84L, "Ciano" to 0xFF2EC4FFL, "Viola" to 0xFFB388FFL, "Bianco" to 0xFFFFFFFFL,
    )
    val conv = runCatching { Conv.valueOf(c.conv) }.getOrDefault(Conv.NONE)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("< Indietro") }
            Text(
                "Pagina ${idx / Settings.SLOTS + 1} · Quadro ${idx % Settings.SLOTS + 1}",
                fontWeight = FontWeight.Bold,
            )
        }
        SwitchRow("Abilitato", c.enabled) { upd(c.copy(enabled = it)) }

        Text("Tipo di strumento")
        ChipRow(
            GaugeType.entries,
            runCatching { GaugeType.valueOf(c.type) }.getOrDefault(GaugeType.DIAL),
            { it.label },
        ) { upd(c.copy(type = it.name)) }

        Text("PID")
        var pickOpen by remember { mutableStateOf(false) }
        OutlinedButton(onClick = { pickOpen = true }, modifier = Modifier.fillMaxWidth()) {
            Text(all.find { it.id == c.pidId }?.name ?: "— scegli un PID —", maxLines = 1)
        }
        if (pickOpen) {
            PidPickerDialog(all, { upd(c.copy(pidId = it)); pickOpen = false }) { pickOpen = false }
        }

        SwitchRow("Mostra etichetta", c.showLabel) { upd(c.copy(showLabel = it)) }
        Field("Etichetta (vuoto = nome corto del PID)", tLabel) { tLabel = it; upd(c.copy(label = it)) }
        Field("Unità (vuoto = automatica)", tUnit) { tUnit = it; upd(c.copy(unit = it)) }

        Text("Allarmi: il colore cambia oltre queste soglie (nelle unità mostrate)", fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Soglia gialla", tYel, Modifier.weight(1f)) { tYel = it; upd(c.copy(yellow = parseNum(it))) }
            Field("Soglia rossa", tRed, Modifier.weight(1f)) { tRed = it; upd(c.copy(red = parseNum(it))) }
            Field("Allarme basso", tLow, Modifier.weight(1f)) { tLow = it; upd(c.copy(low = parseNum(it))) }
        }

        Text("Decimali")
        ChipRow(listOf(-1, 0, 1, 2, 3), c.decimals, { if (it < 0) "Auto" else it.toString() }) {
            upd(c.copy(decimals = it, intNumbers = false))
        }

        Text("Conversione unità")
        ChipRow(Conv.entries, conv, { it.label }) { upd(c.copy(conv = it.name)) }
        if (conv == Conv.CUSTOM) {
            Field("Formula (A = valore, es. A*0.145)", tConv) { tConv = it; upd(c.copy(convFormula = it)) }
        }

        Text("Colore dell'indicatore")
        ChipRow(colors, colors.find { it.second == c.color } ?: colors[0], { it.first }) { upd(c.copy(color = it.second)) }

        SwitchRow("Lancetta ad alta visibilità", c.hiVis) { upd(c.copy(hiVis = it)) }

        Text("Dimensione nella pagina: ${(sz * 100).toInt()}%", fontSize = 13.sp)
        Slider(
            value = sz, onValueChange = { sz = it },
            onValueChangeFinished = { upd(c.copy(size = sz)) }, valueRange = 0.6f..1.6f,
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Valore minimo", tMin, Modifier.weight(1f)) { tMin = it; upd(c.copy(min = parseNum(it))) }
            Field("Valore massimo", tMax, Modifier.weight(1f)) { tMax = it; upd(c.copy(max = parseNum(it))) }
        }

        SwitchRow("Numeri sulla scala", c.showScale) { upd(c.copy(showScale = it)) }
        SwitchRow("Mostra valori min/max", c.showMinMax) { upd(c.copy(showMinMax = it)) }
        SwitchRow("Mostra il picco sulla scala", c.showPeak) { upd(c.copy(showPeak = it)) }
    }
}


// ---------------------------------------------------------------- scelta PID dalla libreria

@Composable
fun PidPickerDialog(all: List<Pid>, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Chiudi") } },
        title = { Text("Scegli il PID") },
        text = {
            Column {
                OutlinedTextField(
                    q, { q = it }, label = { Text("Cerca (nome o comando)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                val filtered = all.filter {
                    q.isBlank() || it.name.contains(q, true) || it.shortName.contains(q, true) ||
                        it.command.contains(q, true)
                }
                val groups = filtered.groupBy { if (it.custom) "Personalizzati" else it.category.ifBlank { "Altri" } }
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    item { TextButton(onClick = { onPick("-") }) { Text("— vuoto —") } }
                    groups.forEach { (cat, list) ->
                        item {
                            Text(cat, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                        }
                        items(list) { pid ->
                            TextButton(onClick = { onPick(pid.id) }, modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    pid.name + "  ·  " + pid.command + (if (pid.header.isNotEmpty()) " (" + pid.header + ")" else ""),
                                    fontSize = 13.sp,
                                )
                            }
                        }
                    }
                }
            }
        },
    )
}
