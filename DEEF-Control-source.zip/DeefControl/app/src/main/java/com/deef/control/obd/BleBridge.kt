package com.deef.control.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.deef.control.Settings
import java.io.IOException
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Un modo di leggere i dati dall'auto: adattatore ELM327 (Bluetooth classico) oppure dongle BLE ISO-TP. */
interface ObdLink {
    var log: (String) -> Unit
    fun send(cmd: String, timeoutMs: Long = 3000): String
    fun query(cmd: String): String
    fun close()
}

/**
 * Dongle ESP32 "ISOTP BLE bridge" (stesso di Simos Tools): servizio 0xABF0, scrittura 0xABF1, notifiche 0xABF2.
 * Ogni pacchetto: 0xF1, flag, rxID (2 byte), txID (2 byte), lunghezza (2 byte), dati ISO-TP. Solo lettura: nessuna
 * impostazione del dongle viene mai modificata.
 */
@SuppressLint("MissingPermission")
class BleBridgeConnection(private val ctx: Context, private val address: String) : ObdLink {
    override var log: (String) -> Unit = {}

    private class Msg(val flags: Int, val txId: Int, val payload: ByteArray)

    private var gatt: BluetoothGatt? = null
    private var dataChar: BluetoothGattCharacteristic? = null
    @Volatile private var closed = false
    @Volatile private var connected = false
    private val connLatch = CountDownLatch(1)
    private val readyLatch = CountDownLatch(1)
    private var statusChar: BluetoothGattCharacteristic? = null
    private var notifStep = 0
    private val queue = LinkedBlockingQueue<Msg>()

    private var txLogged = 0
    private var reqId = 0x7E0
    private var respId = 0x7E8

    // ricomposizione dei pacchetti divisi (0xF2)
    private var splitBuf: java.io.ByteArrayOutputStream? = null
    private var splitSize = 0
    private var splitCount = 0
    private var splitRx = 0
    private var splitTx = 0

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connected = true
                log("BLE collegato (stato $status)")
                g.requestMtu(247)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                log("BLE scollegato: codice $status (8 = timeout, 19 = chiuso dal dongle, 133 = errore generico)")
                connected = false
                connLatch.countDown()
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            log("MTU BLE: $mtu")
            g.discoverServices()
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val svc = g.getService(uuid16(0xABF0))
            val w = svc?.getCharacteristic(uuid16(0xABF1))
            val n = svc?.getCharacteristic(uuid16(0xABF2))
            if (svc == null || w == null || n == null) {
                log("Servizio 0xABF0 non trovato sul dispositivo")
                connLatch.countDown()
                return
            }
            dataChar = w
            statusChar = svc.getCharacteristic(uuid16(0xABF4))
            g.setCharacteristicNotification(n, true)
            statusChar?.let { g.setCharacteristicNotification(it, true) }
            val d = n.getDescriptor(uuid16(0x2902))
            if (d == null) { connLatch.countDown(); return }
            @Suppress("DEPRECATION")
            run {
                d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                g.writeDescriptor(d)
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            // come Simos App: notifiche attive sia sul canale dati (ABF2) sia su quello di stato (ABF4)
            val sd = statusChar?.getDescriptor(uuid16(0x2902))
            if (notifStep == 0 && sd != null) {
                notifStep = 1
                @Suppress("DEPRECATION")
                run {
                    sd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    g.writeDescriptor(sd)
                }
            } else {
                readyLatch.countDown()
            }
        }

        @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            c.value?.let { onData(it) }
        }
    }

    fun open(stage: (String) -> Unit) {
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        val dev = adapter.getRemoteDevice(address)
        stage("Dongle BLE: collegamento...")
        gatt = dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
        if (!readyLatch.await(15, TimeUnit.SECONDS)) {
            close()
            throw IOException(if (connected) "servizio del dongle non trovato" else "dongle BLE non raggiungibile (acceso e vicino?)")
        }
        stage("Dongle BLE: collegato")
        log("Dongle BLE pronto")
        handshake()
        // prova non bloccante: la centralina risponde a 0100?
        val r = query("0100")
        log(if (r.startsWith("4100")) "Centralina risponde" else "Nessuna risposta a 0100 (quadro acceso?): proseguo")
    }

    /** Come Simos App: password del dongle (firmware v1.09) e richiesta della versione. Solo lettura. */
    private fun handshake() {
        val pw = hexToBytes(Settings.blePassword)
        if (pw != null) {
            writeFrame(0xC7, 0, 0, pw)
            val r = waitFlags(0xFF, 1500)
            log(if (r == null) "Password: nessuna risposta dal dongle"
                else if (r.isNotEmpty() && (r[0].toInt() and 0xFF) == 0xFF) "Password accettata" else "Password NON accettata dal dongle")
        }
        writeFrame(0xD5, 0, 0, ByteArray(0))
        val v = waitFlags(0x95, 1000)
        if (v != null) log("Firmware dongle: " + String(v))
    }

    private fun waitFlags(flags: Int, ms: Long): ByteArray? {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            val m = queue.poll(20, TimeUnit.MILLISECONDS) ?: continue
            if (m.flags == flags) return m.payload
        }
        return null
    }

    private fun writeFrame(flags: Int, rx: Int, tx: Int, body: ByteArray) {
        val w = dataChar ?: throw IOException("non connesso")
        val pkt = ByteArray(8 + body.size)
        pkt[0] = 0xF1.toByte()
        pkt[1] = flags.toByte()
        put16(pkt, 2, rx)
        put16(pkt, 4, tx)
        put16(pkt, 6, body.size)
        System.arraycopy(body, 0, pkt, 8, body.size)
        if (txLogged < 60) { txLogged++; log("TX " + pkt.joinToString("") { "%02X".format(it) }) }
        @Suppress("DEPRECATION")
        run {
            w.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            w.value = pkt
            if (!gatt!!.writeCharacteristic(w)) {
                Thread.sleep(5)
                gatt!!.writeCharacteristic(w)
            }
        }
    }

    override fun send(cmd: String, timeoutMs: Long): String {
        if (closed) throw IOException("annullato")
        // l'unico comando ELM che serve: l'indirizzo della centralina (ATSH 7E0, ...)
        if (cmd.startsWith("ATSH", true)) {
            val id = cmd.substring(4).trim().toIntOrNull(16) ?: 0x7E0
            reqId = if (id == 0x7DF) 0x7E0 else id
            respId = reqId + 8
        }
        return "OK"
    }

    override fun query(cmd: String): String {
        if (closed) throw IOException("annullato")
        if (!connected) throw IOException("collegamento BLE perso")
        val body = hexToBytes(cmd) ?: return ""
        queue.clear()
        writeFrame(0, respId, reqId, body)
        var deadline = System.currentTimeMillis() + 1000
        while (System.currentTimeMillis() < deadline) {
            val m = queue.poll(20, TimeUnit.MILLISECONDS) ?: continue
            if (m.flags != 0 || m.txId != respId) continue
            val p = m.payload
            // risposta negativa "in attesa" (7F xx 78): la centralina sta ancora elaborando
            if (p.size >= 3 && (p[0].toInt() and 0xFF) == 0x7F && (p[2].toInt() and 0xFF) == 0x78) {
                deadline = System.currentTimeMillis() + 2000
                continue
            }
            return p.joinToString("") { "%02X".format(it) }
        }
        return ""
    }

    override fun close() {
        closed = true
        connected = false
        runCatching { gatt?.disconnect() }
        runCatching { gatt?.close() }
        gatt = null
    }

    // ---- ricezione notifiche ----
    private var rxLogged = 0
    private fun onData(d: ByteArray) = synchronized(this) {
        if (d.isEmpty()) return@synchronized
        if (rxLogged < 60) { rxLogged++; log("RX " + d.joinToString("") { "%02X".format(it) }.take(80)) }
        val split = splitBuf
        if (split != null && (d[0].toInt() and 0xFF) == 0xF2 && d.size >= 2) {
            if ((d[1].toInt() and 0xFF) != (splitCount and 0xFF)) { splitBuf = null; return@synchronized }
            split.write(d, 2, d.size - 2)
            splitCount++
            if (split.size() >= splitSize) {
                queue.put(Msg(0, splitTx, split.toByteArray().copyOf(splitSize)))
                splitBuf = null
            }
            return@synchronized
        }
        splitBuf = null
        var pos = 0
        while (d.size - pos >= 8) {
            if ((d[pos].toInt() and 0xFF) != 0xF1) break
            val flags = d[pos + 1].toInt() and 0xFF
            val tx = get16(d, pos + 4)
            val size = get16(d, pos + 6)
            pos += 8
            val avail = d.size - pos
            if (size > avail) {
                if (flags and 8 != 0) {
                    val b = java.io.ByteArrayOutputStream()
                    b.write(d, pos, avail)
                    splitBuf = b
                    splitSize = size
                    splitCount = 1
                    splitTx = tx
                }
                return@synchronized
            }
            queue.put(Msg(flags, tx, d.copyOfRange(pos, pos + size)))
            pos += size
        }
    }

    companion object {
        fun uuid16(v: Int): UUID = UUID.fromString(String.format("%08x-0000-1000-8000-00805f9b34fb", v))
        private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = (v and 0xFF).toByte(); b[o + 1] = ((v shr 8) and 0xFF).toByte() }
        private fun get16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
        private fun hexToBytes(s: String): ByteArray? {
            val t = s.replace(" ", "")
            if (t.length % 2 != 0 || t.isEmpty()) return null
            return try { ByteArray(t.length / 2) { t.substring(it * 2, it * 2 + 2).toInt(16).toByte() } } catch (e: Exception) { null }
        }

        /** Cerca dispositivi BLE per qualche secondo e li comunica con nome e indirizzo. */
        fun scan(ctx: Context, durationMs: Long, onFound: (String, String) -> Unit, onDone: () -> Unit) {
            val adapter: BluetoothAdapter? = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            val scanner = adapter?.bluetoothLeScanner
            if (scanner == null) { onDone(); return }
            val h = Handler(Looper.getMainLooper())
            val seen = HashSet<String>()
            val callback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, r: ScanResult) {
                    try {
                        val name = r.scanRecord?.deviceName ?: r.device.name ?: return
                        if (seen.add(r.device.address)) onFound(name, r.device.address)
                    } catch (e: Exception) { }
                }
            }
            runCatching { scanner.startScan(callback) }
            h.postDelayed({
                runCatching { scanner.stopScan(callback) }
                onDone()
            }, durationMs)
        }
    }
}
