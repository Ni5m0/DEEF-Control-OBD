package com.deef.control.car

/** Servizio sperimentale: stesse schermate, ma dichiarato con categoria POI e modello mappa. */
class DeefCarAppServiceBeta : DeefCarAppService() {
    override val beta: Boolean = true
}
