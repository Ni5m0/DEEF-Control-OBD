package com.deef.control

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager

/** Raccoglie le informazioni utili a capire perche l'app non compare in Android Auto. */
object AaDiag {
    fun report(ctx: Context): String {
        val pm = ctx.packageManager
        val sb = StringBuilder()
        fun line(k: String, v: String) { sb.append(k).append(": ").append(v).append('\n') }
        line("Telefono", Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")")
        line("Versione DEEF", runCatching { pm.getPackageInfo(ctx.packageName, 0).versionName ?: "?" }.getOrDefault("?"))
        line("Pacchetto", ctx.packageName)
        // chi ha installato l'app
        val installer = runCatching {
            if (Build.VERSION.SDK_INT >= 30) {
                val s = pm.getInstallSourceInfo(ctx.packageName)
                "installer=" + s.installingPackageName + " iniziatore=" + s.initiatingPackageName
            } else @Suppress("DEPRECATION") ("installer=" + pm.getInstallerPackageName(ctx.packageName))
        }.getOrDefault("non leggibile")
        line("Installata da", installer)
        // Android Auto
        val aa = runCatching { pm.getPackageInfo("com.google.android.projection.gearhead", 0).versionName }.getOrNull()
        line("Android Auto", aa ?: "non visibile/non installato")
        // servizi auto dichiarati e abilitati
        val svcs = listOf(".car.DeefCarAppService", ".car.DeefCarAppServiceBeta")
        svcs.forEach { n ->
            val cn = ComponentName(ctx.packageName, ctx.packageName.let { "com.deef.control" } + n)
            val st = runCatching { pm.getComponentEnabledSetting(cn) }.getOrNull()
            val txt = when (st) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> "abilitato"
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED -> "DISABILITATO"
                PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> "predefinito (manifest)"
                else -> "?"
            }
            line("Servizio" + n, txt)
        }
        val found = runCatching {
            pm.queryIntentServices(Intent("androidx.car.app.CarAppService").setPackage(ctx.packageName), 0).size
        }.getOrDefault(-1)
        line("Servizi auto trovati", found.toString())
        // permessi e batteria
        if (Build.VERSION.SDK_INT >= 31) {
            line("Permesso Bluetooth (connessione)", yn(ctx.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED))
            line("Permesso Bluetooth (ricerca)", yn(ctx.checkSelfPermission(android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED))
        }
        line("Permesso posizione", yn(ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED))
        val pw = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager
        line("Batteria senza restrizioni", yn(pw?.isIgnoringBatteryOptimizations(ctx.packageName) == true))
        if (Build.VERSION.SDK_INT >= 28) {
            val um = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? android.app.usage.UsageStatsManager
            val b = um?.appStandbyBucket
            val name = when (b) { 10 -> "ACTIVE"; 20 -> "WORKING_SET"; 30 -> "FREQUENT"; 40 -> "RARE"; 45 -> "RESTRICTED"; 50 -> "NEVER"; else -> b?.toString() ?: "?" }
            line("Stato risparmio energia", name)
        }
        line("Layout Android Auto", Settings.aaLayout)
        line("Schermo auto rilevato", if (Settings.carW > 0) Settings.carW.toString() + "x" + Settings.carH else "mai (l'app non e mai partita in auto)")
        return sb.toString()
    }

    private fun yn(b: Boolean) = if (b) "sì" else "NO"
}
