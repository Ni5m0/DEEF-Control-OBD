plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val deefSuffix = (project.findProperty("deefSuffix") as String?) ?: ""

android {
    namespace = "com.deef.control"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.deef.control"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0-ELM327-ESP32"
        // Con deefSuffix=".v2" (gradle.properties) l'app diventa un pacchetto separato "DEEF 2",
        // installabile accanto a quella gia presente, con impostazioni proprie.
        applicationIdSuffix = deefSuffix
        manifestPlaceholders["appLabel"] = if (deefSuffix.isEmpty()) "DEEF Control" else "DEEF 2"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    // nome del file APK: DEEF-Control-<versione>.apk (invece di app-debug.apk)
    applicationVariants.all {
        val v = this
        outputs.all {
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl).outputFileName =
                "DEEF-Control-" + v.versionName + (if (deefSuffix.isEmpty()) "" else "-v2") + ".apk"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.car.app:app:1.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
